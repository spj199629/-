// components/tabbar/tabbar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    cstate:Number,
    userIdentify:Number
  },

  /**
   * 组件的初始数据
   */
  data: {
    tabbar: [
      { class: 'icon-shouye', text: '首页', state: 1,nav:'/pages/index/index'},
      { class: 'icon-gerenzhongxin', text: '个人中心', state: 2, nav:'/pages/engineer/engineer'},
      { class: 'icon-guanyuwomen', text: '关于我们', state:3,nav: "/pages/about/about" }
    ],
  },

  /**
   * 组件的方法列表
   */
  methods: {
    navigateto:function(e){
      var url = e.target.dataset.url
      if (url =='/pages/personal/gcs'){
        if (this.data.userIdentify != 1 && this.data.userIdentify != 2){
          url = '/pages/myOrder/myOrder'
        }
      }
      wx.redirectTo({
        url: url
      })
    }
  }
})
