//app.js
App({
  data: {
    //server: 'http://192.168.0.251/clgf/',
    server: 'https://bg.tover.group/clgf/',
    smsserver: 'http://gf.tover.group/',
    version: '',
    openId: ''
  }
})