// pages/order/order.js
const app = getApp()
const timeUtil = require('../../utils/timeUtil.js')
const pickDateUtil = require('../../utils/pickDateUtil.js')
const threadAmount = 2
var threadFinish = 0
let rate = 1
wx.getSystemInfo({
  success: function (res) {
    rate = 550 / res.windowWidth
  },
})
Page({

  /**
   * 页面的初始数据
   */
  data: {
    top: 0,
    zhi: 0,
    //租用车辆信息
    cartypeList: [],
    //rentFormone:{},
    //日期与时间
    startDate: '',
    endDate: '',
    timeArray: [['00', '01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'], ['00', '30']],
    //位置
    mapLocation: [{
      latitude: 29.582170,
      longitude: 106.560580,
      addressName: '请选择施工地点',
      address: '点击地图选择位置',
      iconPath: '../../resource/location.png',
      width: 30,
      height: 30
    }],
    isDefaultLocation: true,
    //车辆
    carTypeArray: [],
    pickCarType: [],
    //车辆选择

    recommendResult: '',
    //高度与半径
    height: 0,
    radius: 0,
    //车辆参数图
    cartypeId: 0,
    carImageUrl: '',
    //汽车数量
    carnum : 1,
    carList: {},//汽车类型参数
    //预计时长区间
    mintime: 0,
    maxtime: 0
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      wx.hideLoading()
    }
  },

  //高度输入
  inputHeight: function (e) {
    const page = this
    const height = (Number)(e.detail.value)
    const radius = page.data.radius
    //实际需要臂长
    var bichang = height + radius+2
    //console.log(bichang)
    const carTypeArray = page.data.carTypeArray
    page.setData({
      height: height
    })
    for (var i = 0; i < carTypeArray.length; i++) {
      var length = (Number)(carTypeArray[i].length)
      if (length >= bichang) {
        page.setData({
          carList: carTypeArray[i],
          cartypeId: carTypeArray[i].typeId,
          haveRecommend: true,
          recommendResult: carTypeArray[i].length + '米',
          carImageUrl: app.data.smsserver + carTypeArray[i].img_fanwei
        })
        console.log(app.data.smsserver + carTypeArray[i].img_fanwei);
        break
      }
    }
    if (bichang > (Number)(carTypeArray[carTypeArray.length - 1].length)) {
      wx.showModal({
        title: '无合适车辆',
        content: '施工范围过高，暂无合适车辆，请联系客服核实',
        showCancel: false
      })
      page.setData({
        carImageUrl: app.data.server + 'appResource/car/car0_v1.png',
        haveRecommend: false,
        recommendResult: '无合适车辆',
      })
    }
  },

  //半径输入
  inputRadius: function (e) {
    const page = this
    const radius = (Number)(e.detail.value)
    const height = page.data.height
    //实际需要臂长
    var bichang = height + radius + 2
    //console.log(bichang)
    const carTypeArray = page.data.carTypeArray
    page.setData({
      radius: radius
    })
    for (var i = 0; i < carTypeArray.length; i++) {
      var length = (Number)(carTypeArray[i].length)
      if (length >= bichang) {
        page.setData({
          carList: carTypeArray[i],
          cartypeId: carTypeArray[i].typeId,
          haveRecommend: true,
          recommendResult: carTypeArray[i].length + '米',
          carImageUrl: app.data.smsserver + carTypeArray[i].img_fanwei
        })
        break
      }
    }
    if (bichang > (Number)(carTypeArray[carTypeArray.length - 1].length)) {
      wx.showModal({
        title: '无合适车辆',
        content: '施工范围过大，暂无合适车辆，请联系客服核实',
        showCancel: false
      })
      page.setData({
        carImageUrl: app.data.server + 'appResource/car/car0_v1.png',
        haveRecommend: false,
        recommendResult: '无合适车辆',
      })
    }
  },

  //预览车辆大图
  previewImage: function () {
    var page = this
    wx.previewImage({
      current: page.data.carImageUrl,
      urls: [
        page.data.carImageUrl
      ]
    })
  },

  //添加车辆
  addcartype: function (e) {
    const page = this
    //获取要上传的汽车类型集合
    var cartypeList = page.data.cartypeList
    cartypeList.push(page.data.carList)
    page.setData({
      cartypeList: cartypeList,
      carnum: cartypeList.length+"辆"
    })
    //console.log(page.data.cartypeList)
  },

  //删除已选车辆
  del: function (e) {
    const page = this
    var cartypeList = page.data.cartypeList
    var start = (e.currentTarget.id)
    cartypeList.splice(start, 1);
    page.setData({
      cartypeList: cartypeList,
      carnum: cartypeList.length + "辆"
    })
    //console.log(cartypeList)
  },

  //表单提交
  rentFormSubmit: function () {
    wx.showLoading({
      title: '正在保存',
      mask: true
    })
    const page = this
    const cartypeList = page.data.cartypeList
    
    //非空验证
    if (page.data.cartypeList.length == 0) {
      cartypeList.push(page.data.carList)
      page.setData({
        cartypeList: cartypeList
      })
    }
    wx.hideLoading()
    wx.navigateTo({
      url: '../order/order?cartypeList=' + JSON.stringify(cartypeList),
    })

    //nullItem.length = 0////////////////////////////////不验证
    //表单整理
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: ' 正在加载',
      mask: true
    })
    this.current = 0
    threadFinish = 0
    const page = this
    //var rentFormone = JSON.parse(options.rentForm)
    //获取车辆类型
    wx.request({
      url: app.data.server + 'carType.php',
      success: function (carRes) {
        if (carRes.data != -1 && carRes.data != 0) {
          const carArray = carRes.data
          var array = []
          for (var i = 0; i < carArray.length; i++) {
            if (i == 0){
              var aas = carArray[i].length + '米',
              img_fanwei = carArray[i].img_fanwei,
              cartypeId = carArray[i].typeId,
              array = carArray[i]
            }
            //array.push(carArray[i].length + '米' + carArray[i].quality + 'kg')
          }
          //console.log(img_fanwei);
          page.setData({
            cartypeId: cartypeId,
            recommendResult:aas,
            carImageUrl: app.data.smsserver + img_fanwei,
            carTypeArray: carArray,
            carList: array
          })
          page.threadController()
        }
      }
    })
    
    //获取车辆选择器最大值和最小值
    wx.request({
      url: app.data.server + '/config.php',
      success: function (carRes) {
        if (carRes.data != -1) {
          const config = carRes.data
          page.setData({
            config: config
          })
          console.log(config)
          page.threadController()
        }
      }
    })
    //系统时间
    var nowDate = new Date()
    const startDate = pickDateUtil.formatTime(nowDate)
    const endDate = pickDateUtil.formatTime(new Date(nowDate.setDate(nowDate.getDate() + 30)))
    page.setData({
      //rentFormone: rentFormone,
      startDate: startDate,
      endDate: endDate
    })

    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var onnum = this.data.onnum + 1
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    /*var rentFormone = this.data.rentFormone
    var cartypeList = rentFormone.cartypeList
    console.log(cartypeList)
    var num = cartypeList.length
    //cartypeList[num] = []
    if (num==1){
      rentFormone.cartypeList = []
    }else{
      cartypeList.pop()
      rentFormone.cartypeList = cartypeList
    }
    
    console.log(num)
    console.log(rentFormone.cartypeList)
    this.setData({
      rentFormone: rentFormone
    })*/
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})