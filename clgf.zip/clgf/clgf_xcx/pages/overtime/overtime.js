// pages/myOrderInfo/myOrderInfo.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    price:0,
    carPrice: [],
    orderId: 0,

    pickservicetime: ['1小时', '2小时', '3小时', '4小时', '5小时', '6小时', '7小时', '8小时'],
    servicetime: '请选择',
  },

  //时间选择
  pickPredictTime: function (e) {
    var page = this
    const index = e.detail.value
    const servicetime = this.data.pickservicetime[index]
    
    this.setData({
      servicetime: servicetime
    })

    wx.request({
      url: app.data.server + 'overtime.php',
      data: {
        orderId: this.data.orderId,
        overtime: this.data.servicetime
      },
      success: function (res) {
        if (res.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '请求失败',
            content: '网络请求错误，请稍后再试',
            showCancel: false,
          })
        }else{
          
          //总金额
          var orderse = res.data
          var price = 0
          for (var i = 0; i < orderse.length; i++) {
            price += orderse[i].price
          }
          page.setData({
            carPrice: res.data,
            price: price
          })
          console.log(res.data)
        }
      }
    })
  },

  //在线支付
  onlinePay: function () {
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'overtimePay.php',
      data: {
        orderId: page.data.orderId,
        overtime: page.data.servicetime
      },
      success: prePayBack => {
        if (prePayBack.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '操作失败',
            content: '网络请求错误，请稍后再试',
            showCancel: false,
          })
        } else {
          wx.requestPayment({
            appId: prePayBack.data.appId,
            nonceStr: prePayBack.data.nonceStr,
            package: prePayBack.data.package,
            signType: prePayBack.data.signType,
            timeStamp: prePayBack.data.timeStamp,
            paySign: prePayBack.data.paySign,
            success: function (success) {
              wx.hideLoading()
              //支付成功--修改状态
              wx.request({
                url: app.data.server + 'overtimegetMoney.php',
                data: {
                  orderId: page.data.orderId,
                  overtime: page.data.servicetime
                },
                success: function (backRes) {
                  wx.hideLoading()
                  if (backRes.data == 1) {
                    //调取短信--通知用户
                    wx.request({
                      url: app.data.server + 'duanxin.php',
                      data: {
                        types: 6,
                        orderId: page.data.orderId
                      },
                      success: function (es){
                        console.log(es.data)
                      }
                    })
                    wx.showModal({
                      title: '支付成功',
                      content: '您的订单已经延时，您可以在订单中心查看',
                      showCancel: false,
                      success: res => {
                        if (res.confirm) {
                          wx.navigateBack({
                            delta: 2
                          })
                        }
                      }
                    })
                  } else {
                    wx.showModal({              
                      title: '提交失败',
                      content: '网络出错，请稍后再试',
                      showCancel: false
                    })
                  }
                }
              })
            },
            fail: function (fail) {
              wx.hideLoading()
              wx.showModal({
                title: '支付失败',
                content: '您取消了支付或者网络请求错误，未完成支付（未扣款）',
                showCancel: false,
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var orderId
    if (typeof (options.orderId) == 'undefined') {
      orderId = decodeURIComponent(options.scene)
    } else {
      orderId = options.orderId
    }
    this.setData({
      orderId: orderId
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})