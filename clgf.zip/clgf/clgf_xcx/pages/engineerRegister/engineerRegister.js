// pages/engineerRegister/engineerRegister.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: {},
    avatarUrl: '../../resource/location.png',
    nickName: '未授权',
    shouquan: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    cstate:3
  },

  /**
     * 生命周期函数--监听页面加载
     */
  /*onLoad: function (options) {

  },*/

  onLoad: function () {
    var page = this
    var userInfo = {}


    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openid, sessionKey, unionId
        wx.request({
          url: app.data.server + 'openId.php',
          data: {
            code: res.code
          },
          success: back => {
            userInfo.openid = back.data.openid
            page.setData({
              userInfo: userInfo,
            })
            // 查看是否授权
            wx.getSetting({
              success: function (res) {
                //console.log(res.authSetting['scope.userLocation'])//用户地理位置授权
                //console.log(res.authSetting['scope.userInfo'])//用户信息授权
                if (res.authSetting['scope.userInfo']) {
                  // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                  wx.getUserInfo({
                    success: function (res) {
                      //console.log(res)
                      userInfo.nickName = res.userInfo.nickName
                      userInfo.avatarUrl = res.userInfo.avatarUrl
                      page.setData({
                        userInfo: userInfo,
                        shouquan: true,
                        nickName: res.userInfo.nickName,
                        avatarUrl: res.userInfo.avatarUrl,
                      })
                      //console.log(userInfo)
                    }
                  })
                }
              }
            })
          }
        })
      }
    })
  },

  //按钮授权返回结果
  bindGetUserInfo: function (e) {
    //console.log(e.detail.userInfo)
    var userInfo = this.data.userInfo
    userInfo.nickName = e.detail.userInfo.nickName
    userInfo.avatarUrl = e.detail.userInfo.avatarUrl
    this.setData({
      userInfo: userInfo,
      shouquan: true,
      nickName: e.detail.userInfo.nickName,
      avatarUrl: e.detail.userInfo.avatarUrl,
    })
    //console.log(userInfo)

  },

  //注册表单提交
  registerForm: function (e) {
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    if (e.detail.value.username == '' || e.detail.value.phone == '' || e.detail.value.phone.length != 11 || e.detail.value.idcard == '' || e.detail.value.idcard.length != 18) {
      wx.hideLoading()
      wx.showModal({
        title: '信息不完整',
        content: '请检查',
        showCancel: false
      })
    } else {
      var userInfo = this.data.userInfo
      userInfo.username = e.detail.value.username
      userInfo.phone = e.detail.value.phone
      userInfo.idcard = e.detail.value.idcard
      //提交登记
      wx.request({
        url: app.data.server + 'engineerRegister.php',
        data: {
          userInfo: userInfo
        },
        success: backRegister => {
          if (backRegister.data == 1) {
            wx.hideLoading()
            wx.showModal({
              title: '登记成功',
              content: '管理员审核通过后，您可以在本小程序内\'工程师\'管理自己的工作。',
              showCancel: false,
              success: res => {
                if (res.confirm) {
                  wx.reLaunch({
                    url: '../index/index',
                  })
                }
              }
            })
          } else if (backRegister.data == -2) {
            wx.hideLoading()
            wx.showModal({
              title: '登记失败',
              content: '身份证号已被绑定，如有疑问，请联系客服',
              showCancel: false,
            })
          } else if (backRegister.data == -3){
            wx.hideLoading()
            wx.showModal({
              title: '登记失败',
              content: '手机号已被绑定，如有疑问，请联系客服',
              showCancel: false,
            })
          }else{
            wx.hideLoading()
            wx.showModal({
              title: '登记失败',
              content: '网络请求出错，请稍后再试',
              showCancel: false,
            })
          }
        }
      })
    }
  },

  

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  /*onShow: function () {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    var userInfo = {}
    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openid, sessionKey, unionId
        wx.request({
          url: app.data.server + 'openId.php',
          data: {
            code: res.code
          },
          success: back => {
            userInfo.openid = back.data.openid




            //获取用户信息
            wx.getUserInfo({
              success: res => {
                wx.hideLoading()
                userInfo.nickName = res.userInfo.nickName
                userInfo.avatarUrl = res.userInfo.avatarUrl
                page.setData({
                  userInfo: userInfo
                })
              },
              fail: resFail => {
                wx.getSetting({
                  success(res) {
                    if (!res.authSetting['scope.userInfo']) {
                      wx.hideLoading()
                      wx.showModal({
                        title: '您拒绝了登陆授权',
                        content: '我们需要获取您的公开昵称和头像来进行注册登记。点击确定后将跳转到设置，请打开用户信息授权。',
                        showCancel: false,
                        success: function (res) {
                          if (res.confirm) {
                            wx.openSetting({})
                          }
                        }
                      })
                    }
                  }
                })
              }
            })
          }
        })
      }
    })
  },*/

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    return {
      title: '高空作业车工程师注册',
      path: '/pages/engineerRegister/engineerRegister'
    }
  }
})