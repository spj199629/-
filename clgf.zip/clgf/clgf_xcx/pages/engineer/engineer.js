// pages/engineer/engineer.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    /***日历****/
    year: 0,
    month: 0,
    date: ['日', '一', '二', '三', '四', '五', '六'],
    dateArr: [],
    isToday: 0,
    isTodayWeek: false,
    todayIndex: 0,
    /****end****/
    engineer: {
      avatarUrl: '../../resource/location.png'
    },
    workbtn: [
      {
        color: 'rgb(6, 235, 243)',
        text: '请假管理',
        bind: 'leaveManager'
      },
      {
        color: ' rgb(231, 75, 3)',
        text: '订单管理',
        bind:'myOrder'
      },
      {
        color: ' rgb(231, 75, 3)',
        text: '管理中心',
        bind: 'managelogolist'
      }

    ],
    cstate: 2,
  },

  //登录按钮
  managelogolist: function(){
    var engineer = this.data.engineer
    console.log(engineer);
    if (engineer.accredit == 1) {
      wx.navigateTo({
        url: '../backsystem/backsystem',
      })
    }else{
      this.showmanage()
    }
  },

  //打开后台登录模块
  showmanage: function () {
    this.setData({
      managestate: true
    })
  },

  //关闭后台登录模块
  hidemanage: function () {
    this.setData({
      name: "",
      password: "",
      managestate: false
    })
  },

  //提交管理员登录信息
  manage_logo: function (e) {
    var page = this;
    if (e.detail.value.name == '' || e.detail.value.password == '') {
      wx.hideLoading()
      wx.showModal({
        title: '信息不完整',
        content: '请检查',
        showCancel: false
      })
    } else {
      //提交登记
      wx.request({
        url: app.data.server + 'binding.php',
        data: {
          openId: app.data.openId,
          name: e.detail.value.name,
          password: e.detail.value.password,
        },
        success: function (e) {
          console.log(e.data)
          if (e.data != -1) {
            if (e.data != -2) {
              if (e.data != -3){
                if(e.data != 0){
                  wx.showModal({
                    title: '操作成功',
                    content: '登录成功',
                    showCancel: false,//是否显示取消按钮
                    cancelText: '否',//默认是“取消”
                    confirmText: '是',
                    success: function (res) {
                      if (res.cancel) {
                        //点击取消,默认隐藏弹框
                      } else {
                        //点击确定
                        wx.navigateTo({
                          //url: '../myOrderInfo/myOrderInfo?order=' + JSON.stringify(order),
                          url: '../backsystem/backsystem',
                        })
                      }
                    },
                    fail: function (res) { },
                    complete: function (res) { },
                  })
                }else{
                  wx.showModal({
                    title: '操作失败',
                    content: '账号或密码错误',
                    showCancel: false,
                  })
                }
              }else{
                wx.showModal({
                  title: '操作失败',
                  content: '授权失败',
                  showCancel: false,
                })
              }
            } else {
              wx.showModal({
                title: '操作失败',
                content: '工程师和后台管理员账号所属公司不一致',
                showCancel: false,
              })
            }
            page.hideedit()
          }else{
            wx.showModal({
              title: '操作失败',
              content: '网络连接失败',
              showCancel: false,
            })
          }
        }
      })
    }
  },


  //打开更新信息面板
  showedit: function () {
    this.setData({
      mapstart: true,
      isRuleTrue: true
    })
  },

  //关闭更新信息面板
  hideedit: function () {
    this.setData({
      user_name: "",
      phone: "",
      mapstart: false,
      isRuleTrue: false
    })
  },

  //表单提交
  registerForm: function (e) {
    var page = this;
    if (e.detail.value.phone == '' || e.detail.value.phone.length != 11) {
      wx.hideLoading()
      wx.showModal({
        title: '信息不完整',
        content: '请检查',
        showCancel: false
      })
    } else {
      //提交登记
      wx.request({
        url: app.data.server + 'engineeredit.php',
        data: {
          openId: app.data.openId,
          phone: e.detail.value.phone,
        },
        success: function (e) {
          if (e.data != -1) {
            if (e.data != -2){
              var userlist = e.data
              wx.showModal({
                title: '操作成功',
                content: '信息修改成功',
                showCancel: false,
              })
              var engineer = page.data.engineer
              engineer.username = userlist.username
              engineer.phone = userlist.phone
              page.setData({
                engineer: engineer,
              })
            }else{
              wx.showModal({
                title: '操作失败',
                content: '此手机号已被绑定！',
                showCancel: false,
              })
            }
            page.hideedit()
          }
        }
      })
    }
  },

  //我的订单
  myOrder: function () {
    wx.navigateTo({
      url: '../engineerOrder/engineerOrder',
    })
  },

  //更新我的信息
  updateInfo: function (e) {
    wx.redirectTo({
      url: '../engineerRegister/engineerRegister',
    })
  },

  //我的代金券
  couponlist: function (e) {
    wx.navigateTo({
      url: '../coupon/coupon',
    })
  },

  //工作详情
  workInfo: function (e) {
    var work = this.data.engineer.waitingWork[e.currentTarget.dataset.index]
    wx.navigateTo({
      url: '../workInfo/workInfo?work=' + JSON.stringify(work)
    })
  },

  //请假管理
  leaveManager: function () {
    wx.navigateTo({
      url: '../leaveManager/leaveManager',
    })
  },

  //工作记录
  workRecords: function () {
    wx.navigateTo({
      url: '../workRecords/workRecords',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var page = this
    /**日历**/
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    let riqi = (year + "-" + month + "-" + now.getDate()).replace(/-/g, '/');
    //console.log(riqi)
    let timestamp = parseInt((new Date(riqi)) / 1000);
    page.dateInit();
    page.setData({
      year: year,
      month: month,
      isToday: '' + year + month + now.getDate(),
      timestamp: timestamp
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'getEngineer.php',
      data: {
        openId: app.data.openId
      },
      success: resInfo => {
        wx.hideLoading()
        page.setData({
          engineer: resInfo.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.showLoading({
      title: '正在刷新',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'getEngineer.php',
      data: {
        openId: app.data.openId
      },
      success: resInfo => {
        wx.hideLoading()
        page.setData({
          engineer: resInfo.data
        })
        wx.stopPullDownRefresh()
      }
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  /****日历****/
  //选择日期
  daychoice: function (e) {
    const page = this
    var daytime = (e.currentTarget.id)
    wx.navigateTo({
      url: '../worklist/worklist?daytime=' + JSON.stringify(daytime)
    })
  },

  //日历
  dateInit: function (setYear, setMonth) {
    var page = this;
    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = [];						//需要遍历的日历数组数据
    let arrLen = 0;							//dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();					//没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 1 : (month + 1);
    let startWeek = new Date(year + '/' + (month + 1) + '/' + 1).getDay();							//目标月1号对应的星期
    let dayNums = new Date(year, nextMonth, 0).getDate();				//获取目标月有多少天
    let obj = {};
    let num = 0;
    let yue_xiaoshi = 0;
    let xiaoshi = "";
    let classs = "";

    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    arrLen = startWeek + dayNums;
    //获取每天是否有工作
    wx.request({
      url: app.data.server + 'daibangongzuo.php',
      data: {
        Year: year,//年
        Month: month + 1,//月
        dayNums: dayNums,//天数
        openId: app.data.openId
      },
      success: function (carRes) {
        if (carRes.data != -1) {
          //console.log(carRes.data)
          let daystate = carRes.data.carstate
          for (let i = 0; i < arrLen; i++) {
            if (i >= startWeek) {
              num = i - startWeek + 1;
              let daysta = daystate[i - startWeek].state
              if (daysta == 1) {
                classs = "choice";
                xiaoshi = daystate[i - startWeek].xiaoshi+"小时"
              } else if(daysta == 2) {
                classs = "day-bg-wu";
                xiaoshi = "无记录";
              } else {
                classs = "day-bg-dgz";
                xiaoshi = "待完成";
              }
              let riqi = (year + "-" + (month + 1) + "-" + num).replace(/-/g, '/')
              obj = {
                isToday: '' + year + (month + 1) + num,
                dateNum: num,
                xiaoshi: xiaoshi,
                classs: classs,
                riqi: riqi,
                timestamp: parseInt((new Date(riqi)) / 1000)
              }
            } else {
              obj = {};
            }
            dateArr[i] = obj;
          }
          //console.log(dateArr)
          page.setData({
            daystate: arrLen,
            dateArr: dateArr,
            yue_xiaoshi: carRes.data.yue_xiaoshi
          })
        }
      }
    })



    let nowDate = new Date();
    let nowYear = nowDate.getFullYear();
    let nowMonth = nowDate.getMonth() + 1;
    let nowWeek = nowDate.getDay();
    let getYear = setYear || nowYear;
    let getMonth = setMonth >= 0 ? (setMonth + 1) : nowMonth;

    if (nowYear == getYear && nowMonth == getMonth) {
      this.setData({
        isTodayWeek: true,
        todayIndex: nowWeek
      })
    } else {
      this.setData({
        isTodayWeek: false,
        todayIndex: -1
      })
    }
  },
  lastMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  },
  nextMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  }

})