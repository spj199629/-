// pages/workInfo/workInfo.js
const app = getApp()
const timeUtil = require('../../utils/timeUtil.js')
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js')
const threadAmount = 4
var threadFinish = 0

Page({

  /**
   * 页面的初始数据
   */
  data: {
    rentForm: {},
    haveStart: false,
    end: false,
    timingText: '',
    pauseTime: [],
    restartTime: [],
    pause: false,
    countDownList: [],
    actEndTimeList: [],
    workType: '请选择',
    blockType: '请选择',
    workTypeId: '',
    blockTypeId: ''
  },

  //点击地址打开地图导航
  click: function (e) {
    var page = this
    wx.openLocation({
      latitude: (Number)(page.data.rentForm.workLatitude),
      longitude: (Number)(page.data.rentForm.workLongitude),
      scale: 18,
      name: page.data.rentForm.workaddressName,
      address: page.data.rentForm.workaddresslist
    })
  },

  //联系现场
  callLinkman: function (res) {
    wx.makePhoneCall({
      phoneNumber: this.data.rentForm.linkmanPhone
    })
  },

  //联系租用人
  callRenter: function (res) {
    wx.makePhoneCall({
      phoneNumber: this.data.rentForm.renterPhone
    })
  },

  //收款
  getMoney: function (res) {
    const page = this
    wx.showModal({
      title: '确认收款',
      content: '已确认收款共计' + this.data.rentForm.payFee + '元',
      cancelText: '否',
      confirmText: '是',
      success: function (modal) {
        if (modal.confirm) {
          wx.showLoading({
            title: '正在保存',
            mask: true
          })
          wx.request({
            url: app.data.server + 'getMoney.php',
            data: {
              orderId: page.data.rentForm.orderId
            },
            success: function (backRes) {
              wx.hideLoading()
              if (backRes.data == 1) {
                page.setData({
                  'rentForm.payState': 1
                })
                wx.showModal({
                  title: '提交成功',
                  showCancel: false
                })
              } else {
                wx.showModal({
                  title: '提交失败',
                  content: '网络出错，请稍后再试',
                  showCancel: false
                })
              }
            }
          })
        }
      }
    })
  },

  //开始施工
  startWork: function (res) {
    var page = this
    if (page.data.rentForm.workTypeId==null){
      var workTypeId = page.data.workTypeId
      var blockTypeId = page.data.blockTypeId
      if (workTypeId == "" || blockTypeId==""){
        wx.showModal({
          title: '错误',
          content: '施工类型和障碍物不能为空',
          showCancel: false
        })
        return;
      }
    }
    
    wx.showModal({
      title: '确认开始施工？',
      content: '确认后将开始计时',
      cancelText: '取消',
      confirmText: '确认',
      success: function (modal1) {
        if (modal1.confirm) {
          wx.showLoading({
            title: '正在提交',
            mask: true
          })
          var startTime = timeUtil.formatTime(new Date())
          wx.request({
            url: app.data.server + 'startWork.php',
            data: {
              orderId: page.data.rentForm.orderId,
              startTime: startTime,
              workTypeId: workTypeId,
              blockTypeId: blockTypeId
            },
            success: function (resB) {
              wx.hideLoading()

              //console.log(resB.data)
              //console.log(resB.data.state)
              //console.log(resB.data.estimate_endtime)
              if (resB.data.state == 1) {
                page.setData({
                  'rentForm.startTime': startTime,
                  //'rentForm.estimate_endtime': resB.data.estimate_endtime,
                  actEndTimeList: resB.data.estimate_endtime,
                  haveStart: true,
                  pause: false
                })
                //page.myTiming()
                page.countDown();
              } else {
                wx.showModal({
                  title: '提交失败',
                  content: '网络请求出错，请稍后再试',
                  showCancel: false
                })
              }
            }
          })
        }
      }
    })
  },

  //暂停计时
  pauseTime: function () {
    var page = this
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    var startTime = timeUtil.formatTime(new Date())
    wx.request({
      url: app.data.server + 'pause_time.php',
      data: {
        orderId: page.data.rentForm.orderId,
        startTime: startTime
      },
      success: function (resB) {
        wx.hideLoading()
        if (resB.data == 1) {
          page.setData({
            pause: true
          })
        } else if (resB.data == 2){
          wx.showModal({
            title: '操作失败',
            content: '您已经操作过一次，不能再次操作！',
            showCancel: false
          })
        } else {
          wx.showModal({
            title: '提交失败',
            content: '网络请求出错，请稍后再试',
            showCancel: false
          })
        }
      }
    })
  },

  //恢复计时
  restartTime: function () {
    var page = this
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    var startTime = timeUtil.formatTime(new Date())
    wx.request({
      url: app.data.server + 'restart_time.php',
      data: {
        orderId: page.data.rentForm.orderId,
        startTime: startTime
      },
      success: function (resB) {
        wx.hideLoading()

        //console.log(resB.data)
        //console.log(resB.data.state)
        //console.log(resB.data.estimate_endtime)
        if (resB.data.state == 1) {
          page.setData({
            //'rentForm.startTime': startTime,
            //'rentForm.estimate_endtime': resB.data.estimate_endtime,
            actEndTimeList: resB.data.estimate_endtime,
            haveStart: true,
            pause: false
          })
          //page.myTiming()
          page.countDown()
        } else {
          wx.showModal({
            title: '提交失败',
            content: '网络请求出错，请稍后再试',
            showCancel: false
          })
        }
      }


      /*success: function (resB) {
        wx.hideLoading()
        if (resB.data == 1) {
          wx.request({
            url: app.data.server + 'get_pause_time.php',
            data: {
              orderId: page.data.rentForm.orderId,
            },
            success: function (resB1) {
              if (resB1.data == -1) {
                wx.hideLoading()
                wx.showModal({
                  title: '加载失败',
                  content: '网络请求出错，请稍后再试',
                  showCancel: false
                })
              } else {
                wx.request({
                  url: app.data.server + 'get_restart_time.php',
                  data: {
                    orderId: page.data.rentForm.orderId,
                  },
                  success: function (res2) {
                    wx.hideLoading()
                    if (res2.data == -1) {
                      wx.showModal({
                        title: '加载失败',
                        content: '网络请求出错，请稍后再试',
                        showCancel: false
                      })
                    } else {
                      page.setData({
                        pauseTime: resB1.data,
                        restartTime: res2.data,
                        pause: false
                      })
                      //page.myTiming()
                      this.countDown()
                    }
                  }
                })
              }
            }
          })
        } else {
          wx.showModal({
            title: '提交失败',
            content: '网络请求出错，请稍后再试',
            showCancel: false
          })
        }
      }*/
    })
  },

  //结束施工
  endWork: function (res) {
    var page = this
    wx.showModal({
      title: '确认结束施工？',
      content: '',
      cancelText: '取消',
      confirmText: '确认',
      success: function (modal1) {
        if (modal1.confirm) {
          wx.showLoading({
            title: '正在提交',
            mask: true
          })
          var endTime = timeUtil.formatTime(new Date())
          var month = (new Date()).getMonth() + 1
          wx.request({
            url: app.data.server + 'endWork.php',
            data: {
              orderId: page.data.rentForm.orderId,
              endTime: endTime,
              startTime: page.data.rentForm.startTime,
              month: month,
              carLicense: page.data.rentForm.carLicense
            },
            success: function (resB) {
              wx.hideLoading()
              if (resB.data != -1) {
                wx.showModal({
                  title: '订单完成！',
                  content: '',
                  showCancel: false,
                  success: function (M1) {
                    if (M1.confirm) {
                      page.evaluate()
                    }
                  }
                })
                /*var st = new Date(page.data.rentForm.startTime)
                var et = new Date(endTime)
                var restHour = 2
                if (month < 6 || month > 9) {
                  restHour = 1
                }
                var hourDif = (et - st) / 3600000
                var dif = Math.round(hourDif)
                dif -= restHour
                if (dif <= 8) {
                  //无加班
                  wx.showModal({
                    title: '订单完成！',
                    content: '无加班费',
                    showCancel: false,
                    success: function (M1) {
                      if (M1.confirm) {
                        page.evaluate()
                      }
                    }
                  })
                } else if (dif > 8) {
                  dif -= 8
                  //加班
                  var op = resB.data
                  wx.showModal({
                    title: '加班' + dif + '小时',
                    content: '加班费每小时' + op + '元，' + '共计' + (op * dif) + '元。确认收款后完成订单。（不含午休时间：6、7、8、9月午休2小时，其他月午休1小时）',
                    showCancel: false,
                    success: function (M1) {
                      if (M1.confirm) {
                        page.evaluate()
                      }
                    }
                  })
                }*/
              } else {
                wx.showModal({
                  title: '提交失败',
                  content: '网络请求出错，请稍后再试',
                  showCancel: false
                })
              }
            }
          })
        }
      }
    })
  },

  //立即评价
  evaluate: function () {
    var page = this
    wx.showModal({
      title: '现场人是否愿意立即评价？',
      content: '确定后将生成评价二维码，对方扫一扫即可',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({
            title: '正在生成',
            mask: true
          })
          wx.request({
            url: app.data.server + 'qrCode.php',
            data: {
              orderId: page.data.rentForm.orderId
            },
            success: function (back) {
              wx.hideLoading()
              page.setData({
                end: true
              })
              if (back.data != -1) {
                wx.previewImage({
                  urls: [app.data.server + 'qr_code/' + page.data.rentForm.orderId + '.png'],
                })
              }  else {
                wx.showModal({
                  title: '生成失败',
                  showCancel: false,
                  success: function (m) {
                    if (m.confirm) {
                      wx.navigateBack()
                    }
                  }
                })
              }
            }
          })
        } else {
          wx.navigateBack()
        }
      }
    })
  },

  //计时器
  myTiming: function () {
    const page = this
    var pauseTime = page.data.pauseTime
    if (pauseTime.length > 0) {
      var secondesDif = 0
      var minutesDif = 0
      var hoursDif = 0
      var dayDif = 0
      for (var i = 0; i < pauseTime.length; i++) {
        if (i == 0) {
          var startTime = new Date(page.data.rentForm.startTime.replace(/-/g, '/'))
        } else {
          var startTime = new Date(page.data.restartTime[i - 1].replace(/-/g, '/'))
        }
        var timeDif = new Date(new Date(page.data.pauseTime[i].replace(/-/g, '/')) - startTime)
        secondesDif += timeDif.getSeconds()
        minutesDif += timeDif.getMinutes()
        hoursDif += (timeDif.getHours() - 8)
        dayDif += (timeDif.getDate() - 1)
      }
      var startTime = new Date(page.data.restartTime[page.data.restartTime.length - 1].replace(/-/g, '/'))
      var timeDif = new Date(new Date() - startTime)
      secondesDif += timeDif.getSeconds()
      minutesDif += timeDif.getMinutes()
      hoursDif += (timeDif.getHours() - 8)
      dayDif += (timeDif.getDate() - 1)
      if (dayDif > 1) {
        hoursDif += 24 * (dayDif - 1)
      }
      page.setData({
        timingText: hoursDif + '小时' + minutesDif + '分' + secondesDif + '秒'
      })
      if (!page.data.pause) {
        setTimeout(function () {
          page.myTiming()
        }, 1000)
      }
    } else {
      const startTime = new Date(page.data.rentForm.startTime.replace(/-/g, '/'))
      var timeDif = new Date(new Date() - startTime)
      var secondesDif = timeDif.getSeconds()
      var minutesDif = timeDif.getMinutes()
      var hoursDif = timeDif.getHours() - 8
      var dayDif = timeDif.getDate()
      if (dayDif > 1) {
        hoursDif += 24 * (dayDif - 1)
      }
      page.setData({
        timingText: hoursDif + '小时' + minutesDif + '分' + secondesDif + '秒'
      })
      if (!page.data.pause) {
        setTimeout(function () {
          page.myTiming()
        }, 1000)
      }
    }
  },

  timeFormat(param) {//小于10的格式化函数
    return param < 10 ? '0' + param : param;
  },
  countDown: function () {//倒计时函数
    const page = this
    // 获取当前时间，同时得到活动结束时间数组
    var newTime = new Date().getTime();
    var endTimeList = page.data.actEndTimeList;
    var countDownArr = [];

    // 对结束时间进行处理渲染到页面
    var endTime = new Date(endTimeList).getTime();
    //let obj = null;
    // 如果活动未结束，对时间进行处理
    /*wx.showModal({
      title: '时间',
      content: '结束时间：' + endTime + "当前时间：" + newTime,
    })*/
    if (endTime - newTime > 0) {
      var time = (endTime - newTime) / 1000;
      // 获取天、时、分、秒
      var day = parseInt(time / (60 * 60 * 24));
      var hou = parseInt(time % (60 * 60 * 24) / 3600);
      var min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
      var sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
      day = page.timeFormat(day)
      hou = page.timeFormat(hou)
      min = page.timeFormat(min)
      sec = page.timeFormat(sec)
      page.setData({
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    } else {//活动已结束，全部设置为'00'
      day = '00'
      hou = '00'
      min = '00'
      sec = '00'
      page.setData({
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    }
    
    //countDownArr.push(obj);
    // 渲染，然后每隔一秒执行一次倒计时函数
    //page.setData({ countDownList: countDownArr })
    if (!page.data.pause) {
      //setTimeout(page.countDown(), 1000);
      setTimeout(function () {
        page.countDown()
      }, 1000)
    }
  },

  //施工类型选择
  pickWorkType: function (e) {
    var index = e.detail.value
    //空项转换
    if (index[0] == null) {
      index[0] = this.data.workTypeIndex[0]
    }
    if (index[1] == null) {
      index[1] = this.data.workTypeIndex[1]
    }
    //确定索引
    const workTypeArray = this.data.workTypeArray
    var workType = this.data.pickWorkType[0][index[0]]
    var workTypeId = 0
    if (!this.data.pickWorkType[1][index[1]]) {
      for (var i = 0; i < workTypeArray.length; i++) {
        if (workType == workTypeArray[i].name) {
          workTypeId = workTypeArray[i].id
        }
      }
    } else {
      var typeTemp = this.data.pickWorkType[1][index[1]]
      workType += typeTemp
      for (var i = 0; i < workTypeArray.length; i++) {
        if (typeTemp == workTypeArray[i].name) {
          workTypeId = workTypeArray[i].id
        }
      }
    }
    //刷新数据
    this.setData({
      workType: workType,
      workTypeId: workTypeId
    })
  },
  //施工类型列表更新
  pickWorkTypeColumn: function (e) {
    var page = this
    switch (e.detail.column) {
      case 0:
        //第一列更新
        const workTypeArray = page.data.workTypeArray
        var array2 = []
        for (var i = 0; i < workTypeArray.length; i++) {
          if (workTypeArray[i].parentId == workTypeArray[e.detail.value].id) {
            array2.push(workTypeArray[i].name)
          }
        }
        page.setData({
          'pickWorkType[1]': array2,
          'workTypeIndex[0]': e.detail.value
        })
        break
      case 1:
        //第二列更新
        page.setData({
          'workTypeIndex[1]': e.detail.value
        })
        break
    }
  },

  //选择障碍物
  pickBlock: function (e) {
    const index = e.detail.value
    const blockType = this.data.pickBlockType[index]
    const blockTypeArray = this.data.blockTypeArray
    var blockTypeId = 0
    for (var i = 0; i < blockTypeArray.length; i++) {
      if (blockType == blockTypeArray[i].name) {
        blockTypeId = blockTypeArray[i].id
      }
    }
    this.setData({
      blockType: blockType,
      blockTypeId: blockTypeId
    })
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      wx.hideLoading()
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var rentForm = JSON.parse(options.work)
    var haveStart = false
    var pause = false
    var end = false


    //倒计时
    let endTimeList = [];
    var estimate_endtime = rentForm.estimate_endtime
    // 将活动的结束时间参数提成一个单独的数组，方便操作
    this.setData({ actEndTimeList: estimate_endtime });

    if (rentForm.startTime != null) {
      haveStart = true
    }
    if (rentForm.is_pause == 1) {
      pause = true
    }
    if (rentForm.endTime != null) {
      end = true
    }
    var page = this
    wx.showLoading({
      title: '正在加载',
      mask: true
    })


    wx.request({
      url: app.data.server + 'get_pause_time.php',
      data: {
        orderId: rentForm.orderId
      },
      success: function (resB) {
        if (resB.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '加载失败',
            content: '网络请求出错，请稍后再试',
            showCancel: false
          })
        } else {
          wx.request({
            url: app.data.server + 'get_restart_time.php',
            data: {
              orderId: rentForm.orderId
            },
            success: function (res2) {
              wx.hideLoading()
              if (res2.data == -1) {
                wx.showModal({
                  title: '加载失败',
                  content: '网络请求出错，请稍后再试',
                  showCancel: false
                })
              } else {
                page.setData({
                  pauseTime: resB.data,
                  restartTime: res2.data,
                  rentForm: rentForm,
                  haveStart: haveStart,
                  end: end,
                  pause: pause
                })
                if (haveStart && !pause) {

                  // 执行倒计时函数
                  page.countDown();
                  page.threadController()
                  //page.myTiming()
                }
              }
            }
          })
        }
      }
    })

    //获取施工类型
    wx.request({
      url: app.data.server + 'workType.php',
      success: function (workRes) {
        if (workRes.data != -1 && workRes.data != 0) {
          const workTypeArray = workRes.data
          var array1 = []
          for (var i = 0; i < workTypeArray.length; i++) {
            if (workTypeArray[i].parentId == 0) {
              array1.push(workTypeArray[i].name)
            }
          }
          var array2 = []
          for (var i = 0; i < workTypeArray.length; i++) {
            if (workTypeArray[i].parentId == workTypeArray[0].id) {
              array2.push(workTypeArray[i].name)
            }
          }
          var pickWorkType = [array1, array2]
          page.setData({
            workTypeArray: workTypeArray,
            pickWorkType: pickWorkType
          })
          page.threadController()
        }
      }
    })
    //获取障碍物类型
    wx.request({
      url: app.data.server + 'blockType.php',
      success: function (blockRes) {
        if (blockRes.data != -1 && blockRes.data != 0) {
          const blockArray = blockRes.data
          var array = []
          for (var i = 0; i < blockArray.length; i++) {
            array.push(blockArray[i].name)
          }
          page.setData({
            blockTypeArray: blockArray,
            pickBlockType: array
          })
          page.threadController()
        }
      }
    })
    //获取车辆最后位置
    wx.request({
      url: app.data.server + 'cargps.php',
      data: {
        carLicense: rentForm.carLicense
      },
      success: function (blockRes) {
        //console.log(blockRes.data)
        
        if (blockRes.data != -1 && blockRes.data != 0) {
          //计算距离
          //const blockArray = blockRes.data
          const blockArray = blockRes.data.cargps;
          const juli = blockRes.data.juli;
          console.log(blockArray)
          console.log(juli)
          //计算距离
          var qqmap = new QQMapWX({
            key: '2TABZ-HVRWF-QZWJK-J62DB-ZM453-BQBN4'
          })
          qqmap.calculateDistance({
            mode: 'driving',
            from: {
              latitude: rentForm.workLatitude,//起点坐标
              longitude: rentForm.workLongitude
            },
            to: [{
              latitude: blockArray.tx_latitude,
              longitude: blockArray.tx_longitude
            }],
            success: distanceBack => {
              //console.log(distanceBack)
              var distance = distanceBack.result.elements[0].distance
              console.log(distance)
              if (distance < juli){//当距离小于2000米时，显示状态为允许
                var displaystate = true;
              }else{
                var displaystate = false;
              }
              //console.log("距离："+distance)
              page.setData({
                distance: distance,
                displaystate: displaystate
              })
              page.threadController()
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})