// pages/engineerapply/engineerapply.js
//工程师申请管理
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  //同意
  activation: function (e) {
    const page = this
    var carArray = this.data.carArray
    var id = (e.currentTarget.id)
    wx.request({
      url: app.data.server + 'engineerappledit.php',
      data: {
        openId: id,
        state: 1,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          //工程师信息
          wx.request({
            url: app.data.server + 'engineerlist.php',
            data: {
              openId: app.data.openId,
            },
            success: function (res) {
              if (res.data != -1 && res.data != 0) {
                const engineerlist = res.data
                console.log(engineerlist);
                page.setData({
                  engineerlist: engineerlist.gongchengshi,
                })
              }
            },
            fail: resFail => {
              wx.showModal({
                title: "失败",
                content: "请求失败",
                showCancel: false
              })
            }
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  //拒绝
  stop: function (e) {
    const page = this
    var id = (e.currentTarget.id)
    wx.request({
      url: app.data.server + 'engineerappledit.php',
      data: {
        openId: id,
        state: 2,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          ///工程师信息
          wx.request({
            url: app.data.server + 'engineerlist.php',
            data: {
              openId: app.data.openId,
            },
            success: function (res) {
              if (res.data != -1 && res.data != 0) {
                const engineerlist = res.data
                console.log(engineerlist);
                page.setData({
                  engineerlist: engineerlist.gongchengshi,
                })
              }
            },
            fail: resFail => {
              wx.showModal({
                title: "失败",
                content: "请求失败",
                showCancel: false
              })
            }
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const page = this
    //工程师信息
    wx.request({
      url: app.data.server + 'engineerlist.php',
      data: {
        openId: app.data.openId,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          const engineerlist = res.data
          console.log(engineerlist);
          page.setData({
            //engineerlist中存在三个数组，分为3个模块的数据
            engineerlist: engineerlist.gongchengshi,
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})