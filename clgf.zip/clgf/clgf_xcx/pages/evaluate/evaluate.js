// pages/evaluate/evaluate.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderId: 0,
    anquangan: 0,
    zhuanyegan: 0,
    yuyuegan: 0,
    carScore: 0,
    starArray1: [
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
    ],
    starArray2: [
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
    ],
    starArray3: [
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
    ],
    starArray4: [
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
      '../../resource/starDark.png',
    ],
  },

  //安全感
  star1: function (res) {
    var starArray = []
    var anquangan = res.currentTarget.dataset.index + 1
    switch (res.currentTarget.dataset.index) {
      case 0:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 1:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 2:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 3:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
        ]
        break;
      case 4:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
        ]
        break;
    }
    this.setData({
      starArray1: starArray,
      anquangan: anquangan
    })
  },

  //专业感
  star2: function (res) {
    var starArray = []
    var zhuanyegan = res.currentTarget.dataset.index + 1
    switch (res.currentTarget.dataset.index) {
      case 0:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 1:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 2:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 3:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
        ]
        break;
      case 4:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
        ]
        break;
    }
    this.setData({
      starArray2: starArray,
      zhuanyegan: zhuanyegan
    })
  },

  //愉悦感
  star3: function (res) {
    var starArray = []
    var yuyuegan = res.currentTarget.dataset.index + 1
    switch (res.currentTarget.dataset.index) {
      case 0:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 1:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 2:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 3:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
        ]
        break;
      case 4:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
        ]
        break;
    }
    this.setData({
      starArray3: starArray,
      yuyuegan: yuyuegan
    })
  },


  //工程车辆评价
  star4: function (res) {
    var starArray = []
    var carScore = res.currentTarget.dataset.index + 1
    switch (res.currentTarget.dataset.index) {
      case 0:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 1:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 2:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
          '../../resource/starDark.png',
        ]
        break;
      case 3:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starDark.png',
        ]
        break;
      case 4:
        starArray = [
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
          '../../resource/starLight.png',
        ]
        break;
    }
    this.setData({
      starArray4: starArray,
      carScore: carScore
    })
  },

  //提交
  evaluate: function (res) {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var carScore = this.data.carScore
    var anquangan = this.data.anquangan
    var zhuanyegan = this.data.zhuanyegan
    var yuyuegan = this.data.yuyuegan
    var advice = res.detail.value.advice
    var phone_or_wx = res.detail.value.phone_or_wx
    if (anquangan == 0 && zhuanyegan == 0 && yuyuegan == 0 && carScore == 0 && advice == '') {
      wx.hideLoading()
      wx.showModal({
        title: '评价为空',
        content: '您未进行任何评价',
        showCancel: false
      })
    } else {
      var orderId = this.data.orderId
      //var money = Math.floor(Math.random() * 100 + 1)
      wx.request({
        url: app.data.server + 'evaluate.php',
        data: {
          orderId: orderId,
          anquangan: anquangan,
          zhuanyegan: zhuanyegan,
          yuyuegan: yuyuegan,
          carScore: carScore,
          advice: advice
          // phone_or_wx: phone_or_wx,
          //money: money
        },
        success: function (res) {
          wx.hideLoading()
          if (res.data == 1) {
            wx.showModal({
              title: '评价成功',
              content: '非常感谢您的评价',
              showCancel: false,
              success: function (modal1) {
                //点击确定
                wx.navigateTo({
                  url: '../choujiang5/choujiang5?orderId=' + orderId,
                })
              }
            })
          } else {
            wx.showModal({
              title: '评价失败',
              content: '网络请求出错，请稍后再试',
              showCancel: false
            })
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var orderId
    if (typeof (options.orderId) == 'undefined') {
      orderId = decodeURIComponent(options.scene)
    } else {
      orderId = options.orderId
    }
    this.setData({
      orderId: orderId
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})