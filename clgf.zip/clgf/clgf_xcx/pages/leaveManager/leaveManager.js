// pages/leaveManager/leaveManager.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    previousMonth: '<',
    thisYearMonth: '',
    nextMonth: '>',
    calendarDateArray: [],
    year: '',
    month: ''
  },

  //上月日历
  preMonth: function () {
    var year = this.data.year
    var month = this.data.month
    if (month == 1) {
      month = 12
      year = parseInt(year) - 1
    } else {
      month = parseInt(month) - 1
    }
    this.drawCalendar(year, month);
  },

  //下月日历
  nextMonth: function () {
    var year = this.data.year
    var month = this.data.month
    if (month == 12) {
      month = 1
      year = parseInt(year) + 1
    } else {
      month = parseInt(month) + 1
    }
    this.drawCalendar(year, month);
  },

  //选择日历
  chooseMonth: function (e) {
    var chooseArray = (e.detail.value).split('-')
    var year = chooseArray[0]
    var month = chooseArray[1]
    this.drawCalendar(year, month)
  },

  //绘制日历
  drawCalendar: function (year, month) {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    var days = new Date(year, month, 0).getDate()//本月天数
    var startWeek = (new Date(year + '/' + month + '/1')).getDay()//本月1号星期
    //星期日将0换为7
    if (startWeek == 0) {
      startWeek = 7
    }
    //将当前星期前置空
    var calendarDateArray = new Array()
    for (var i = 1; i < startWeek; i++) {
      var calendarDate = { date: ' ', state: ' ' }
      calendarDateArray.push(calendarDate)
    }
    //填入日期
    for (var i = 1; i <= days; i++) {
      var calendarDate = { date: i, state: ' ' }
      calendarDateArray.push(calendarDate)
    }
    //获取工作和请假情况
    wx.request({
      url: app.data.server + 'getCalendarNote.php',
      data: {
        openid: app.data.openId
      },
      success: function (resBack) {
        wx.hideLoading()
        if (resBack.data != 0) {
          for (var i = 0; i < resBack.data.length; i++) {
            var dateStr = resBack.data[i].date
            var strArray = new Array()
            strArray = dateStr.split('-')
            //本月内有日期需要标注
            if (strArray[0] == year && strArray[1] == month) {
              var dateInt = parseInt(strArray[2])
              var weekInt = parseInt(startWeek)
              var noteCount = dateInt + weekInt - 2//需要标注的日期在calendarDateArray中的下标号
              calendarDateArray[noteCount].state = resBack.data[i].state
            }
          }
        }
        //刷新界面数据
        if ((parseInt(month)) < 10) {
          month = '0' + month
        }
        page.setData({
          calendarDateArray: calendarDateArray,
          year: year,
          month: month,
          thisYearMonth: year + '-' + month
        })
      }
    })
  },

  //请假申请
  askForLeave: function () {
    wx.navigateTo({
      url: '../askForLeave/askForLeave',
    })
  },

  //请假记录
  leaveRecords: function () {
    wx.navigateTo({
      url: '../leaveRecords/leaveRecords',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    //获取当前日期
    var date = new Date()
    var year = date.getFullYear()//年份
    var month = date.getMonth() + 1//月份（从0开始）
    this.drawCalendar(year, month)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})