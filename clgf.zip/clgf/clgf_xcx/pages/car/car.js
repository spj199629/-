// pages/car/car.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  //激活
  activation: function (e) {
    const page = this
    var carArray = this.data.carArray
    var id = (e.currentTarget.id)
    wx.request({
      url: app.data.server + 'caredit.php',
      data: {
        id: id,
        state: 1,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          //获取车辆列表
          wx.request({
            url: app.data.server + 'carlist.php',
            data: {
              openId: app.data.openId,
            },
            success: function (res) {
              if (res.data != -1 && res.data != 0) {
                const carArray = res.data
                page.setData({
                  carArray: carArray,
                })
              }
            },
            fail: resFail => {
              wx.showModal({
                title: "失败",
                content: "请求失败",
                showCancel: false
              })
            }
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  //停止
  stop: function (e) {
    const page = this
    var id = (e.currentTarget.id)
    wx.request({
      url: app.data.server + 'caredit.php',
      data: {
        id: id,
        state: 0,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          //获取车辆列表
          wx.request({
            url: app.data.server + 'carlist.php',
            data: {
              openId: app.data.openId,
            },
            success: function (res) {
              if (res.data != -1 && res.data != 0) {
                const carArray = res.data
                page.setData({
                  carArray: carArray,
                })
              }
            },
            fail: resFail => {
              wx.showModal({
                title: "失败",
                content: "请求失败",
                showCancel: false
              })
            }
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const page = this
    //获取车辆列表
    wx.request({
      url: app.data.server + 'carlist.php',
      data: {
        openId: app.data.openId,
      },
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          const carArray = res.data
          console.log(carArray);
          page.setData({
            carArray: carArray,
          })
        }
      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})