// pages/payInfo/payInfo.js
const app = getApp()
var QQMapWX = require('../../libs/qqmap-wx-jssdk.js')
const threadAmount = 5//并发请求数
var threadFinish = 0

Page({

  /**
   * 页面的初始数据
   */
  data: {
    youhui:false,
    rentForm: {},
    otherText: {},
    price: {},
    discount: {},
    distance: 0,
    kmCost: 0,
    //engineerCostList: [],
    sumCost: 0,
    //siteSumCost: 0,
    onlineSumCost: 0,
    order: {},
    servicetimelist:"0小时",

    //优惠券
    couponlist: {},//用户所有优惠券
    coupon_money: 0,//优惠券总金额
    coupon_num: 0,//优惠券数量
    cou_state: false,//选择状态
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    //console.log(threadFinish)
    if (threadFinish == threadAmount){
      //车辆数量
      var car_num = (Number)(this.data.rentForm.cartypeList.length)
      //距离
      var juli = (Number)((Number(this.data.distance) / 1000).toFixed(2))
      if (juli < 20){
        //里程费
        var kmCost = 0;
      }else{
        var lucheng = (Number)(juli - 20);
        //里程费
        var kmCost = (Number)((car_num * lucheng * (Number)(this.data.price.kmFee)).toFixed(2))
      }
      //选择服务的小时数
      //var fuwu = this.data.otherText.servicetime
      var fuwu = this.data.rentForm.servicetime
      //fuwu = fuwu.replace('小时', '')
      //后台设置的最低小时数
      var zuidi = this.data.timelist.service_time
      var xiaoshi = (Number)(fuwu - zuidi)
      //console.log(xiaoshi)
      //总金额
      var sumCost = 0
      var onlineSumCost = 0
      //var siteSumCost = 0
      var kmC = kmCost
      var onlineCarD = (Number)(this.data.discount.onlineCarDiscount)
      //var onlineEngineerD = (Number)(this.data.discount.onlineEngineerDiscount)
      var onlineKmD = (Number)(this.data.discount.onlineKmDiscount)
      //var siteCarD = (Number)(this.data.discount.siteCarDiscount)
      //var siteEngineerD = (Number)(this.data.discount.siteEngineerDiscount)
      //var siteKmD = (Number)(this.data.discount.siteKmDiscount)
      /*wx.showModal({
        title: "数据",
        content: "距离：" + juli + "路程" + lucheng + "里程费：" + kmCost + "车辆数量：" + car_num + "路程：" + lucheng + "里程单价" + (this.data.price.kmFee) + "折扣：" + onlineCarD + "折扣：" + siteCarD + "折扣：" + onlineKmD + "折扣：" + siteKmD
      })*/
      for (var i = 0; i < this.data.rentForm.cartypeList.length; i++) {
        var carC = (Number)(this.data.rentForm.cartypeList[i].price) + (Number)((this.data.rentForm.cartypeList[i].overPrice) * xiaoshi)
        //工程师费用---目前取消
        //var engineerC = engineerCostList[i]
        //原价总金额
        sumCost += (carC + kmC)
        //在线支付金额
        onlineSumCost += (Number)(carC * onlineCarD + kmC * onlineKmD)
        //现场支付金额
        //siteSumCost += (Number)(carC * siteCarD + kmC * siteKmD)
      }
      sumCost = sumCost.toFixed(2)
      onlineSumCost = onlineSumCost.toFixed(2)
      //siteSumCost = siteSumCost.toFixed(2)

      
      //console.log(sumCost)
      //console.log(onlineSumCost)
      //console.log(siteSumCost)
      //console.log(xiaoshi)
      //折扣文字转换
      var discount = this.data.discount
      for (var key in discount) {
        if (discount[key] == 0) {
          discount[key] = '免费'
        } else if (discount[key] == 1) {
          discount[key] = '原价'
        } else {
          discount[key] = (discount[key] * 10) + '折'
        }
      }
      //整理数据
      var order = {}
      order.orderTime = ''//服务器端：下单时间
      order.workTime = this.data.rentForm.workTime//施工时间
      order.carList = this.data.rentForm.carList//车辆信息
      order.carnum = this.data.rentForm.carnum//车辆信息
      //order.predictTime = this.data.rentForm.predictTime
      order.workaddressName = this.data.rentForm.workaddressName//施工地址--地址名称
      order.workaddresslist = this.data.rentForm.workaddresslist//施工地址--地址详情
      order.workAddress = this.data.rentForm.workAddress//施工地址
      order.workLatitude = this.data.rentForm.workLatitude//施工纬度
      order.workLongitude = this.data.rentForm.workLongitude//施工经度
      order.cartypeList = this.data.rentForm.cartypeList//车辆信息
      //order.workTypeId = this.data.rentForm.workTypeId//施工类型序号
      //order.blockTypeId = this.data.rentForm.blockTypeId//障碍物id
      //order.servicetimeId = this.data.rentForm.servicetimeId
      order.servicetime = this.data.rentForm.servicetime//服务小时
      order.xiaoshi = xiaoshi
      order.carLicense = []//服务器端：分配车牌
      order.engineerOpenId = []//服务器端：分配工程师
      order.renterName = this.data.rentForm.renterName//租用人姓名
      order.renterPhone = this.data.rentForm.renterPhone//租用人手机
      //order.linkmanName = this.data.rentForm.linkmanName
      //order.linkmanPhone = this.data.rentForm.linkmanPhone
      order.payMethod = -1//本页：付款方式
      order.payFee = onlineSumCost//应付金额
      //order.onlineSumCost = siteSumCost//在线支付费用
      order.payState = -1//本页及服务器端：支付状态
      order.workState = 0//服务器端：施工状态
      order.startTime = null//服务器端：开始施工时间
      order.endTime = null//服务器端：结束施工时间
      order.openId = app.data.openId
      order.onlineSumCost = onlineSumCost//实际支付金额
      order.formId = this.data.rentForm.formId
      order.coupon_state = 0//是否使用优惠券
      order.coupon_price = 0//优惠券金额
      order.bus_id = app.data.business.bus_id//所属公司
      //
      this.setData({
        kmCost: kmCost,
        //engineerCostList: engineerCostList,
        discount: discount,
        sumCost: sumCost,
        onlineSumCost: onlineSumCost,
        //siteSumCost: siteSumCost,
        order: order
      })
      wx.hideLoading()
    }
    
  },

  //优惠券选择
  checkboxChange: function () {
    var cou_state = this.data.cou_state;
    var coupon_money = this.data.coupon_money;//优惠的金额
    var order = this.data.order;
    if (cou_state == false){
      var state = true;
      var jine = order.onlineSumCost
      var onlineSumCost = (Number)(jine - coupon_money)
      order.onlineSumCost = onlineSumCost
      order.coupon_state = 1
      order.coupon_price = coupon_money
    }else{
      var state = false;
      var jine = order.onlineSumCost
      var onlineSumCost = (Number)(jine + coupon_money)
      order.onlineSumCost = onlineSumCost
      order.coupon_state = 0
      order.coupon_price = 0
    }

    this.setData({
      order: order,
      onlineSumCost: onlineSumCost,
      cou_state: state
    })
  },

  //删除车辆--更改提交信息
  delcar: function(){
    //车辆数量
    var car_num = (Number)(this.data.rentForm.cartypeList.length)
    //距离
    var juli = (Number)((Number(this.data.distance) / 1000).toFixed(2))
    if (juli < 20) {
      //里程费
      var kmCost = 0;
    } else {
      var lucheng = (Number)(juli - 20);
      //里程费
      var kmCost = (Number)((car_num * lucheng * (Number)(this.data.price.kmFee)).toFixed(2))
    }
    //选择服务的小时数
    //var fuwu = this.data.otherText.servicetime
    var fuwu = this.data.rentForm.servicetime
    //fuwu = fuwu.replace('小时', '')
    //后台设置的最低小时数
    var zuidi = this.data.timelist.service_time
    var xiaoshi = (Number)(fuwu - zuidi)
    //console.log(xiaoshi)
    //总金额
    var sumCost = 0
    var onlineSumCost = 0
    //var siteSumCost = 0
    var kmC = kmCost
    var discount = this.data.discountlist
    var onlineCarD = (Number)(discount.onlineCarDiscount)
    var onlineKmD = (Number)(discount.onlineKmDiscount)
    var siteCarD = (Number)(discount.siteCarDiscount)
    var siteKmD = (Number)(discount.siteKmDiscount)
    /*wx.showModal({
      title: "数据",
      content: "距离：" + juli + "路程" + lucheng + "里程费：" + kmCost + "车辆数量：" + car_num + "路程：" + lucheng + "里程单价" + (this.data.price.kmFee) + "折扣：" + onlineCarD + "折扣：" + siteCarD + "折扣：" + onlineKmD + "折扣：" + siteKmD
    })*/
    for (var i = 0; i < this.data.rentForm.cartypeList.length; i++) {
      var carC = (Number)(this.data.rentForm.cartypeList[i].price) + (Number)((this.data.rentForm.cartypeList[i].overPrice) * xiaoshi)
      //工程师费用---目前取消
      //var engineerC = engineerCostList[i]
      //原价总金额
      sumCost += (carC + kmC)
      //在线支付金额
      onlineSumCost += (Number)(carC * onlineCarD + kmC * onlineKmD)
      //现场支付金额
      //siteSumCost += (Number)(carC * siteCarD + kmC * siteKmD)
    }
    sumCost = sumCost.toFixed(2)
    onlineSumCost = onlineSumCost.toFixed(2)
    //siteSumCost = siteSumCost.toFixed(2)


    //console.log(sumCost)
    //console.log(onlineSumCost)
    //console.log(siteSumCost)
    //console.log(xiaoshi)
    //折扣文字转换
    //var discount = this.data.discount
    for (var key in discount) {
      if (discount[key] == 0) {
        discount[key] = '免费'
      } else if (discount[key] == 1) {
        discount[key] = '原价'
      } else {
        discount[key] = (discount[key] * 10) + '折'
      }
    }
    //整理数据
    var order = {}
    order.orderTime = ''//服务器端：下单时间
    order.workTime = this.data.rentForm.workTime//施工时间
    order.carList = this.data.rentForm.carList//车辆信息
    order.carnum = this.data.rentForm.carnum//车辆信息
    //order.predictTime = this.data.rentForm.predictTime
    order.workaddressName = this.data.rentForm.workaddressName//施工地址--地址名称
    order.workaddresslist = this.data.rentForm.workaddresslist//施工地址--地址详情
    order.workAddress = this.data.rentForm.workAddress//施工地址
    order.workLatitude = this.data.rentForm.workLatitude//施工纬度
    order.workLongitude = this.data.rentForm.workLongitude//施工经度
    order.cartypeList = this.data.rentForm.cartypeList//车辆信息
    //order.workTypeId = this.data.rentForm.workTypeId//施工类型序号
    //order.blockTypeId = this.data.rentForm.blockTypeId//障碍物id
    //order.servicetimeId = this.data.rentForm.servicetimeId
    order.servicetime = this.data.rentForm.servicetime//服务小时
    order.xiaoshi = xiaoshi
    order.carLicense = []//服务器端：分配车牌
    order.engineerOpenId = []//服务器端：分配工程师
    order.renterName = this.data.rentForm.renterName//租用人姓名
    order.renterPhone = this.data.rentForm.renterPhone//租用人手机
    //order.linkmanName = this.data.rentForm.linkmanName
    //order.linkmanPhone = this.data.rentForm.linkmanPhone
    order.payMethod = -1//本页：付款方式
    order.payFee = onlineSumCost//应付金额
    order.onlineSumCost = onlineSumCost//实际支付金额
    order.payState = -1//本页及服务器端：支付状态
    order.workState = 0//服务器端：施工状态
    order.startTime = null//服务器端：开始施工时间
    order.endTime = null//服务器端：结束施工时间
    order.openId = app.data.openId
    order.formId = this.data.rentForm.formId
    order.coupon_state = 0//是否使用优惠券
    order.coupon_price = 0//优惠券金额
    //
    this.setData({
      kmCost: kmCost,
      //engineerCostList: engineerCostList,
      discount: discount,
      sumCost: sumCost,
      onlineSumCost: onlineSumCost,
      order: order,
      cou_state: false,//优惠券
    })
    wx.hideLoading()
  },

  //联系客服
  call: function () {
    wx.showLoading({
      title: '正在获取客服联系方式',
      mask: true
    })
    wx.request({
      url: app.data.server + 'getCallPhone.php',
      success: function (e) {
        wx.hideLoading()
        wx.makePhoneCall({
          phoneNumber: e.data.toString(),
        })
      }
    })
  },

  //删除订单车辆
  del: function (e) {
    const page = this
    var rentForm = page.data.rentForm
    var cartypeList = page.data.rentForm.cartypeList
    if(cartypeList.length<=1){
      wx.showModal({
        title: '删除失败',
        content: '订单车辆不能为空',
      })
      return;
    }
    var start = (e.currentTarget.id)
    cartypeList.splice(start, 1);
    rentForm.cartypeList = cartypeList
    page.setData({
      rentForm: rentForm
    })
    page.delcar();
    //console.log(cartypeList)
  },

  //在线支付
  onlinePay: function () {
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    var page = this
    var order = page.data.order
    order.payMethod = 1
    order.payState = 0
    //console.log(order)
    wx.request({
      url: app.data.server + 'prePay.php',
      data: {
        order: order
      },
      success: prePayBack => {
        if (prePayBack.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '订单创建失败',
            content: '网络请求错误，请稍后再试',
            showCancel: false,
          })
        } else if (prePayBack.data == -2) {
          wx.hideLoading()
          wx.showModal({
            title: '下单失败',
            content: '剩余工程师或车辆不足，请调整订单或稍后再试',
            showCancel: false,
          })
        } else {
          wx.requestPayment({
            appId: prePayBack.data.appId,
            nonceStr: prePayBack.data.nonceStr,
            package: prePayBack.data.package,
            signType: prePayBack.data.signType,
            timeStamp: prePayBack.data.timeStamp,
            paySign: prePayBack.data.paySign,
            success: function (success) {
              wx.hideLoading()
              //支付成功--修改状态
              wx.request({
                url: app.data.server + 'getMoney.php',
                data: {
                  orderId: prePayBack.data.orderId,
                  coupon_state: order.coupon_state,
                  couponId: page.data.couponId
                },
                success: function (backRes) {
                  wx.hideLoading()
                  if (backRes.data == 1) {
                    //调取短信--通知用户
                    wx.request({
                      url: app.data.server + 'duanxin.php',
                      data: {
                        types: 1,
                        orderId: prePayBack.data.orderId
                      },
                    })
                    //调取短信--通知后台管理员
                    wx.request({
                      url: app.data.server + 'duanxin.php',
                      data: {
                        types: 5,
                        orderId: prePayBack.data.orderId
                      },
                    })
                    if (prePayBack.data.is_accept == 1) {
                      //调取短信--通知司机
                      wx.request({
                        url: app.data.server + 'duanxin.php',
                        data: {
                          types: 4,
                          orderId: prePayBack.data.orderId
                        },
                      })
                    }
                    wx.showModal({
                      title: '预定成功',
                      content: '您可以在\'我的订单\'里查看订单记录',
                      showCancel: false,
                      success: res => {
                        if (res.confirm) {
                          wx.navigateTo({
                            url: '../index/index',
                          })
                        }
                      }
                    })
                  } else {
                    wx.showModal({
                      title: '提交失败',
                      content: '网络出错，请稍后再试',
                      showCancel: false
                    })
                  }
                }
              })
            },
            fail: function (fail) {
              //删除订单
              wx.request({
                url: app.data.server + 'deleteOrder.php',
                data: {
                  id: prePayBack.data.orderId
                }
              })
              wx.hideLoading()
              wx.showModal({
                title: '支付失败',
                content: '您取消了支付或者网络请求错误，未完成支付（未扣款）',
                showCancel: false,
              })
            }
          })
        }
      }
    })
  },

  //现场支付
  sitePay: function () {
    var page = this
    wx.showModal({
      title: '确定现场支付吗？',
      content: '在线支付可享受更多优惠！',
      cancelText: '再考虑下',
      confirmText: '现场支付',
      success: function (modal1) {
        if (modal1.confirm) {
          wx.showLoading({
            title: '正在提交',
            mask: true
          })
          var order = page.data.order
          order.payMethod = 0
          order.payState = 0
          //提交订单
          wx.request({
            url: app.data.server + 'submitOrder.php',
            data: {
              order: order
            },
            success: function (submitRes) {
              wx.hideLoading()
              if (submitRes.data.code == 0) {
                wx.showModal({
                  title: '下单成功',
                  content: '我们将尽快处理，接单或拒绝后您都将收到微信通知，您也可以主动联系客服',
                  showCancel: false,
                  success: function (modalS) {
                    if (modalS.confirm) {
                      wx.navigateBack({
                        delta: 2
                      })
                    }
                  }
                })
                //调取短信--通知用户
                wx.request({
                  url: app.data.server + 'duanxin.php',
                  data: {
                    types: 1,
                    orderId: submitRes.data.orderId
                  },
                })
                //调取短信--通知后台管理员
                wx.request({
                  url: app.data.server + 'duanxin.php',
                  data: {
                    types: 5,
                    orderId: submitRes.data.orderId
                  },
                })
                if (submitRes.data.is_accept==1){
                  //调取短信--通知司机
                  wx.request({
                    url: app.data.server + 'duanxin.php',
                    data: {
                      types: 4,
                      orderId: submitRes.data.orderId
                    },
                  })
                }
              } else if (submitRes.data.code == -1) {
                wx.showModal({
                  title: '订单创建失败',
                  content: '网络请求错误，请稍后再试',
                  showCancel: false,
                })
              } else if (submitRes.data.code == -2) {
                wx.showModal({
                  title: '下单失败',
                  content: '剩余工程师或车辆不足，请调整订单或稍后再试',
                  showCancel: false,
                })
              }
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //console.log(options)////////
    wx.showLoading({
      title: '正在计算费用',
      mask: true
    })
    threadFinish = 0
    const page = this
    //接收表单数据
    var rentForm = JSON.parse(options.rentForm)
    //var otherText = JSON.parse(options.otherText)
    //console.log(rentForm)
    var servicetimelist = rentForm.servicetime + '小时'
    page.setData({
      servicetimelist: servicetimelist,
      rentForm: rentForm
    })
    //获取基本价格
    wx.request({
      url: app.data.server + 'price.php',
      success: function (e) {
        page.setData({
          price: e.data
        })
        page.threadController()
      }
    })
    //获取折扣
    wx.request({
      url: app.data.server + 'discount.php',
      success: function (e) {
        page.setData({
          discount: e.data,
          discountlist: e.data
        })
        page.threadController()
      }
    })
    //获取最低时间
    wx.request({
      url: app.data.server + 'zuiditime.php',
      success: function (e) {
        page.setData({
          timelist: e.data
        })
        page.threadController()
      }
    })
    //获取优惠券
    wx.request({
      url: app.data.server + 'coupon.php',
      data:{
        openId: app.data.openId,
      },
      success: function (e) {
        var coupon = e.data;
        var z_price = 0;
        var couponId = "";
        if (coupon != 0) {
          for (var i = 0; i < coupon.length; i++) {
            z_price = parseInt(z_price) + parseInt(coupon[i].money)
            if (couponId == "") {
              couponId = coupon[i].id
            } else {
              couponId = couponId + ":" + coupon[i].id
            }
          }
          page.setData({
            couponId: couponId,
            coupon_money: z_price,
            coupon_num: coupon.length
          })
        }
        page.threadController()
      }
    })
    //计算距离
    var qqmap = new QQMapWX({
      key: '2TABZ-HVRWF-QZWJK-J62DB-ZM453-BQBN4'
    })
    qqmap.calculateDistance({
      mode: 'driving',
      from: {
        latitude: 29.587443,//起点坐标
        longitude: 106.504029
      },
      to: [{
        latitude: rentForm.workLatitude,
        longitude: rentForm.workLongitude
      }],
      success: distanceBack => {
        var distance = distanceBack.result.elements[0].distance
        page.setData({
          distance: distance
        })
        page.threadController()
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})