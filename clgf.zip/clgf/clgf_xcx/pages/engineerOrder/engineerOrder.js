// pages/engineerOrder/engineerOrder.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    myOrder: []
  },

  //订单详情
  myOrderInfo: function (res) {
    var index = res.currentTarget.dataset.index
    var order = this.data.myOrder[index]
    wx.navigateTo({
      url: '../myOrderInfo/myOrderInfo?order=' + JSON.stringify(order),
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'myOrder.php',
      data: {
        openId: app.data.openId
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data == 0) {
          wx.showModal({
            title: '您还没有订单',
            content: '下单后可在此处查看订单记录',
            showCancel: false,
            success: function (no) {
              if (no.confirm) {
                wx.navigateBack()
              }
            }
          })
        } else {
          console.log(res.data)///////
          page.setData({
            myOrder: res.data
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})