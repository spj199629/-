// pages/about/about.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cstate:3,
    index:0,
    idea:[
      { title: '我们的使命', label: '做最安全、专业的高空作业服务', imgurl:'http://gf.tover.group/static/web/image/gk30.jpg'},
      { title: '企业信条', label: '诚信、安全、专业、愉悦感', imgurl: 'http://gf.tover.group/static/web/image/ln.jpg' },
      { title: '行为准则', label: '不蒙骗客户、不恶性竞争、不污染环境', imgurl: '' }
    ],
    course:[
      { time: '2017-10', icon: 'icon-zijin', text:'重庆高空作业车辆最多的私企\n自有资金拥有14-32米高空作业车辆13台',line:1},
      { time: '2017-10', icon: 'icon-zigerenzheng', text: '拥有路灯管护资质\n城市及道路照明工程专业承包三级 ', line: 1 },
      { time: '2017-09', icon: 'icon-fuwu', text: '正式进入高服行业\n主城5万盏路灯更换及喷漆', line: 1 },
      { time: '2017-01', icon: 'icon-zhinengyouhua', text: '全面改革优化\n更名为重庆诚立高服科技有限公司', line: 1 },
      { time: '2016-02', icon: 'icon-ruanqidong', text: '进入路灯管护行业\n达州市经开区路灯项目启动', line: 1 },
      { time: '2015-01', icon: 'icon-xiaofangche', text: '进入消防车行业\n与上海格拉曼合作', line: 1 },
      { time: '2014-08', icon: 'icon-zu', text: '开展租赁业务\n自有第一台14米高空作业车', line: 1 },
      { time: '2013-01', icon: 'icon-xiaoshou', text: '高空作业车销售\n成立重庆诚立汽车销售服务有限公司' },
    ]
  },
  changetable: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      index: index
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})