// pages/askForLeave/askForLeave.js
var app = getApp()
var myDateUtil = require('../../utils/pickDateUtil.js')

Page({

  /**
   * 页面的初始数据
   */
  data: {
    sDate: '',
    eDate: '',
    nowDate: ''
  },

  //开始时间
  sDateChange: function (e) {
    var sDate = e.detail.value
    if (sDate > this.data.eDate) {
      this.setData({
        sDate: sDate,
        eDate: sDate
      })
    } else {
      this.setData({
        sDate: sDate
      })
    }
  },

  //结束时间
  eDateChange: function (e) {
    this.setData({
      eDate: e.detail.value
    })
  },

  //提交
  askForLeave: function (e) {
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    if (e.detail.value.canWork) {
      var canWork = 1
    } else {
      var canWork = 0
    }
    wx.request({
      url: app.data.server + 'askForLeave.php',
      data: {
        openid: app.data.openId,
        sDate: e.detail.value.sDate,
        eDate: e.detail.value.eDate,
        canWork: canWork,
        reason: e.detail.value.reason
      },
      success: function (resBack) {
        wx.hideLoading()
        if (resBack.data == 1) {
          wx.showModal({
            title: '提交成功',
            content: '请假申请已提交，等待审核处理。您可以在请假记录里查看相关情况。',
            showCancel: false,
            success: function (leaveRes) {
              if (leaveRes.confirm) {
                wx.navigateBack({})
              }
            }
          })
        } else if (resBack.data == -1) {
          wx.showModal({
            title: '服务器连接失败',
            content: '请稍后再试',
            showCancel: false
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var date = myDateUtil.formatTime(new Date())
    this.setData({
      sDate: date,
      eDate: date,
      nowDate: date
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})