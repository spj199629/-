// pages/join/join.js
const app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    mail: '',
    radioItem: [
      { name: '是', value: '1' },
      { name: '否', value: '0' }
    ]
  },

  //加入
  join: function (res) {
    var e = res.detail.value
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    if (e.phone.length != 11) {
      wx.hideLoading()
      wx.showModal({
        title: '联系方式错误',
        content: '请检查',
        showCancel: false
      })
    } else if (e.name == '' || e.radioCar == '' || e.radioDrive == '') {
      wx.hideLoading()
      wx.showModal({
        title: '有空缺项',
        content: '请检查',
        showCancel: false
      })
    } else {
      wx.request({
        url: app.data.server + 'join.php',
        data: {
          name: e.name,
          phone: e.phone,
          car: e.radioCar,
          drive: e.radioDrive
        },
        success: function (resBack) {
          wx.hideLoading()
          if (resBack.data == 1) {
            wx.showModal({
              title: '提交成功',
              content: '',
              showCancel: false,
              success: function (mo) {
                if (mo.confirm) {
                  wx.navigateBack()
                }
              }
            })
          } else {
            wx.showModal({
              title: '提交失败',
              content: '网络请求错误，请稍后再试',
              showCancel: false
            })
          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'getMail.php',
      success: function (res) {
        wx.hideLoading()
        page.setData({
          mail: res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})