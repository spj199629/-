// pages/xufei/xufei.js
const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pause: true,
    price: 0,
    carPrice: [],
    orderId: 0,

    pickservicetime: ['1小时', '2小时', '3小时', '4小时', '5小时', '6小时', '7小时', '8小时'],
    servicetime: '请选择',
  },

  //时间选择
  pickPredictTime: function (e) {
    var page = this
    const index = e.detail.value
    const servicetime = this.data.pickservicetime[index]

    this.setData({
      servicetime: servicetime
    })

    wx.request({
      url: app.data.server + 'overtime.php',
      data: {
        orderId: this.data.orderId,
        overtime: this.data.servicetime
      },
      success: function (res) {
        if (res.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '请求失败',
            content: '网络请求错误，请稍后再试',
            showCancel: false,
          })
        } else {

          //总金额
          var orderse = res.data
          var price = 0
          for (var i = 0; i < orderse.length; i++) {
            price += orderse[i].price
          }
          page.setData({
            carPrice: res.data,
            price: price
          })
          console.log(res.data)
        }
      }
    })
  },

  //在线支付
  onlinePay: function () {
    wx.showLoading({
      title: '正在提交',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'overtimePay.php',
      data: {
        orderId: page.data.orderId,
        overtime: page.data.servicetime
      },
      success: prePayBack => {
        if (prePayBack.data == -1) {
          wx.hideLoading()
          wx.showModal({
            title: '操作失败',
            content: '网络请求错误，请稍后再试',
            showCancel: false,
          })
        } else {
          wx.requestPayment({
            appId: prePayBack.data.appId,
            nonceStr: prePayBack.data.nonceStr,
            package: prePayBack.data.package,
            signType: prePayBack.data.signType,
            timeStamp: prePayBack.data.timeStamp,
            paySign: prePayBack.data.paySign,
            success: function (success) {
              wx.hideLoading()
              //支付成功--修改状态
              wx.request({
                url: app.data.server + 'overtimegetMoney.php',
                data: {
                  orderId: page.data.orderId,
                  overtime: page.data.servicetime
                },
                success: function (backRes) {
                  wx.hideLoading()
                  if (backRes.data == 1) {
                    //调取短信--通知用户
                    wx.request({
                      url: app.data.server + 'duanxin.php',
                      data: {
                        types: 6,
                        orderId: page.data.orderId
                      },
                    })
                    wx.showModal({
                      title: '支付成功',
                      content: '您的订单已经延时，您可以在订单中心查看',
                      showCancel: false,
                      success: res => {
                        if (res.confirm) {
                          wx.navigateBack({
                            delta: 2
                          })
                        }
                      }
                    })
                  } else {
                    wx.showModal({
                      title: '提交失败',
                      content: '网络出错，请稍后再试',
                      showCancel: false
                    })
                  }
                }
              })
            },
            fail: function (fail) {
              wx.hideLoading()
              wx.showModal({
                title: '支付失败',
                content: '您取消了支付或者网络请求错误，未完成支付（未扣款）',
                showCancel: false,
              })
            }
          })
        }
      }
    })
  },

  //订单加时
  overtime: function () {
    wx.navigateTo({
      url: '../overtime/overtime?orderId=' + this.data.rentForm.orderId,
    })
  },

  timeFormat(param) {//小于10的格式化函数
    return param < 10 ? '0' + param : param;
  },
  countDown: function () {//倒计时函数
    const page = this
    // 获取当前时间，同时得到活动结束时间数组
    var newTime = new Date().getTime();
    var endTimeList = page.data.rentForm.estimate_endtime;
    var countDownArr = [];

    // 对结束时间进行处理渲染到页面
    var endTime = new Date(endTimeList).getTime();
    //let obj = null;
    // 如果活动未结束，对时间进行处理
    /*wx.showModal({
      title: '时间',
      content: '结束时间：' + endTime + "当前时间：" + newTime,
    })*/
    if (endTime - newTime > 0) {
      var time = (endTime - newTime) / 1000;
      // 获取天、时、分、秒
      var day = parseInt(time / (60 * 60 * 24));
      var hou = parseInt(time % (60 * 60 * 24) / 3600);
      var min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
      var sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
      day = page.timeFormat(day)
      hou = page.timeFormat(hou)
      min = page.timeFormat(min)
      sec = page.timeFormat(sec)
      page.setData({
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    } else {//活动已结束，全部设置为'00'
      day = '00'
      hou = '00'
      min = '00'
      sec = '00'
      page.setData({
        pause: false,
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    }

    //countDownArr.push(obj);
    // 渲染，然后每隔一秒执行一次倒计时函数
    //page.setData({ countDownList: countDownArr })
    if (page.data.pause) {
      //setTimeout(page.countDown(), 1000);
      setTimeout(function () {
        page.countDown()
      }, 1000)
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var order = JSON.parse(options.order)
    var page = this
    var orderId = order.orderId
    console.log(order)
    page.setData({
      rentForm: order,
      orderId: orderId
    })
    page.countDown();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})