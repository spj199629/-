const app = getApp()
Page({
  data: {
    orderId:"",
    size: 600,//转盘大小,
    musicflg: false, //声音
    fastJuedin: false,//快速决定
    repeat: true,//不重复抽取
    probability: true,// 概率
    s_awards: '',//结果
    option: '标题',
    //转盘的总数据，想添加多个可以往这数组里添加一条格式一样的数据
    zhuanpanArr: [
      {
        id: 0,
        option: '辛运大抽奖',//转盘的标题名称
        awards: [
          {
            id: 0,                // id递增
            name: "一等奖",           // 选项名 超过9个字时字体会变小点 大于13个数时会隐藏掉超出的
            price_min: "86",
            price_max: "100",
            color: '#FFA827',         // 选项的背景颜色
            probability: 10       // 概率 0代表永远也转不到这个选项，数字越大概率也就越大,data中的probability属性设置为true时是才生效, 这属性也必须填写，不填写会出错
          },
          {
            id: 1,
            name: "二等奖",
            price_min: "71",
            price_max: "85",
            color: '#AA47BC',
            probability: 10
          },
          {
            id: 2,
            name: "三等奖",
            price_min: "56",
            price_max: "70",
            color: '#42A5F6',
            probability: 10
          },
          {
            id: 3,
            name: "四等奖",
            price_min: "41",
            price_max: "55",
            color: '#66BB6A',
            probability: 10
          },
          {
            id: 4,
            name: "五等奖",
            price_min: "21",
            price_max: "40",
            color: '#FFA500',
            probability: 10
          },
          {
            id: 4,
            name: "六等奖",
            price_min: "1",
            price_max: "20",
            color: '#FF4500',
            probability: 10
          }
        ]
      }
    ],
    //更改数据可以更改这属性，格式要像下面这样写才行
    awardsConfig: {
      option: '辛运大抽奖',//转盘的标题名称
      awards: [
        {
          id: 0,                // id递增
          name: "一等奖",           // 选项名 超过9个字时字体会变小点 大于13个数时会隐藏掉超出的
          price_min: "86",
          price_max: "100",
          color: '#FFA827',         // 选项的背景颜色
          probability: 10       // 概率 0代表永远也转不到这个选项，数字越大概率也就越大,data中的probability属性设置为true时是才生效, 这属性也必须填写，不填写会出错
        },
        {
          id: 1,
          name: "二等奖",
          price_min: "71",
          price_max: "85",
          color: '#AA47BC',
          probability: 10
        },
        {
          id: 2,
          name: "三等奖",
          price_min: "56",
          price_max: "70",
          color: '#42A5F6',
          probability: 10
        },
        {
          id: 3,
          name: "四等奖",
          price_min: "41",
          price_max: "55",
          color: '#66BB6A',
          probability: 10
        },
        {
          id: 4,
          name: "五等奖",
          price_min: "21",
          price_max: "40",
          color: '#FFA500',
          probability: 10
        },
        {
          id: 4,
          name: "六等奖",
          price_min: "1",
          price_max: "20",
          color: '#FF4500',
          probability: 10
        }
      ]
    }
  },

  //接收当前转盘初始化时传来的参数
  getData(e) {
    this.setData({
      option: e.detail.option
    })
  },

  //接收当前转盘结束后的答案选项
  getAwards(e) {
    var price = 0;
    var b = "";
    var a = this.data.awardsConfig.awards
    if (e.detail=='一等奖'){
      for (var i = 0; i < a.length;i++){
        if (a[i].name =="一等奖"){
          b = a[i]
          break
        }
      }
    } else if (e.detail == '二等奖'){
      for (var i = 0; i < a.length; i++) {
        if (a[i].name == "二等奖") {
          b = a[i]
          break
        }
      }
    } else if (e.detail == '三等奖') {
      for (var i = 0; i < a.length; i++) {
        if (a[i].name == "三等奖") {
          b = a[i]
          break
        }
      }
    } else if (e.detail == '四等奖') {
      for (var i = 0; i < a.length; i++) {
        if (a[i].name == "四等奖") {
          b = a[i]
          break
        }
      }
    } else if (e.detail == '五等奖') {
      for (var i = 0; i < a.length; i++) {
        if (a[i].name == "五等奖") {
          b = a[i]
          break
        }
      }
    } else if (e.detail == '六等奖') {
      for (var i = 0; i < a.length; i++) {
        if (a[i].name == "六等奖") {
          b = a[i]
          break
        }
      }
    }
    if (e.detail == b.name) {
      var price_min = a[i].price_min
      var price_max = a[i].price_max
    }

    // Math.floor(Math.random() * 305 + 1);
    // Math.floor(Math.random() * 100 + 1)
    price_min = Math.ceil(price_min);
    price_max = Math.floor(price_max);
    var price = Math.floor(Math.random() * (price_min - price_max)) + price_max;

    wx.request({
      url: app.data.server + 'choujiang.php',
      data: {
        openId: app.data.openId,
        orderId: this.data.orderId,
        price: price,
        state: 0,
      },
      success: function (ras) {
        console.log(e)
        if (ras.data != 0) {
          wx.showModal({
            title: '中奖了',
            content: '恭喜您获得了' + price + '元抵扣金',
            showCancel: false,
            success: function (res) {
              if (res.cancel) {
                //点击取消,默认隐藏弹框
              } else {
                //点击确定
                wx.navigateTo({
                  url: '../index/index',
                })
              }
            },
          })
        }
      }
    })








    
    
    this.setData({
      s_awards: e.detail,
    })
  },

  //开始转动或者结束转动
  startZhuan(e) {
    this.setData({
      zhuanflg: e.detail ? true : false
    })
  },

  //切换转盘选项
  switchZhuanpan(e) {
    //当转盘停止时才执行切换转盘
    if (!this.data.zhuanflg) {
      var idx = e.currentTarget.dataset.idx, zhuanpanArr = this.data.zhuanpanArr, obj = {};
      for (let i in zhuanpanArr) {
        if (this.data.option != zhuanpanArr[i].option && zhuanpanArr[i].id == idx) {
          obj.option = zhuanpanArr[i].option;
          obj.awards = zhuanpanArr[i].awards;
          this.setData({
            awardsConfig: obj //其实默认要更改当前转盘的数据要传个这个对象，才有效果
          })
          break;
        }
      }
    }
  },

  //转盘声音
  switch1Change1(e) {
    var value = e.detail.value;
    if (this.data.zhuanflg) {
      wx.showToast({
        title: '当转盘停止转动后才有效',
        icon: 'none'
      })
      return;
    } else {
      this.setData({
        musicflg: value
      })
    }
  },

  //不重复抽取
  switch1Change2(e) {
    var value = e.detail.value;
    if (this.data.zhuanflg) {
      wx.showToast({
        title: '当转盘停止转动后才有效',
        icon: 'none'
      })
      return;
    } else {
      this.setData({
        repeat: value
      })
    }
  },

  //快速决定
  switch1Change3(e) {
    var value = e.detail.value;
    if (this.data.zhuanflg) {
      wx.showToast({
        title: '当转盘停止转动后才有效',
        icon: 'none'
      })
      return;
    } else {
      this.setData({
        fastJuedin: value
      })
    }
  },

  //概率 == 如果不重复抽取开启的话 概率是无效的
  switch1Change4(e) {
    var value = e.detail.value;
    if (this.data.zhuanflg) {
      wx.showToast({
        title: '当转盘停止转动后才有效',
        icon: 'none'
      })
      return;
    } else {
      this.setData({
        probability: value
      })
    }
  },

  onLoad: function (options) {
    //实例化组件对象，这样有需要时就能调用组件内的方法
    this.zhuanpan = this.selectComponent("#zhuanpan");
    var orderId = options.orderId
    this.setData({
      orderId: orderId
    })

    //可以这样调用 示例：this.zhuanpan.switchZhuanpan(data); 
    //上面这方法可用来切换转盘选项数据，参数可以看组件构造器中的switchZhuanpan方法
  }
})
