// pages/workRecords/workRecords.js
var app = getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    orders: [{}]
  },

  //订单点击详情
  ordersInfo: function (e) {
    var work = this.data.orders[e.currentTarget.dataset.index]
    wx.navigateTo({
      url: '../workInfo/workInfo?work=' + JSON.stringify(work)
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var page = this
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    wx.request({
      url: app.data.server + 'getWorkRecords.php',
      data: {
        openId: app.data.openId
      },
      success: function (resWorkRecords) {
        wx.hideLoading()
        if (resWorkRecords.data == -1) {
          wx.showModal({
            title: '服务器连接失败',
            content: '无法连接到数据库，请稍后再试',
            showCancel: false,
            success: res => {
              if (res.confirm) {
                wx.navigateBack({})
              }
            }
          })
        } else if (resWorkRecords.data == 0) {
          wx.showModal({
            title: '没有已完成工作',
            content: '完成后可在此页面查看工作详情',
            showCancel: false,
            success: res => {
              if (res.confirm) {
                wx.navigateBack({})
              }
            }
          })
        } else {
          page.setData({
            orders: resWorkRecords.data
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})