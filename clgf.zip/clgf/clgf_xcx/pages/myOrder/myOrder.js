// pages/myOrder/myOrder.js
const app = getApp()
const threadAmount = 2
var threadFinish = 0

Page({

  /**
   * 页面的初始数据
   */
  data: {
    myOrder: [],
    shouquan: true,
    cstate:2
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      wx.hideLoading()
    }
  },

  //我的代金券
  couponlist: function (e) {
    wx.navigateTo({
      url: '../coupon/coupon',
    })
  },

  //打开更新信息面板
  showedit: function () {
    this.setData({
      mapstart: true,
      isRuleTrue: true
    })
  },

  //关闭更新信息面板
  hideedit: function () {
    this.setData({
      user_name: "",
      phone: "",
      mapstart: false,
      isRuleTrue: false
    })
  },

  //表单提交
  registerForm: function (e) {
    var page = this;
    if (e.detail.value.user_name == '' || e.detail.value.phone == '' || e.detail.value.phone.length != 11) {
      wx.hideLoading()
      wx.showModal({
        title: '信息不完整',
        content: '请检查',
        showCancel: false
      })
    } else {
      //提交登记
      wx.request({
        url: app.data.server + 'usersadd.php',
        data: {
          types: "edit",
          openId: app.data.openId,
          user_name: e.detail.value.user_name,
          phone: e.detail.value.phone,
        },
        success: function (e) {
          if (e.data != -1) {
            if (e.data != -2){
              var userlist = e.data
              wx.showModal({
                title: '操作成功',
                content: '信息修改成功',
                showCancel: false,
              })
              page.setData({
                userlist: userlist,
                user_name: "",
                phone: "",
                shouquan: true,
              })
              page.hideedit()
            }else{
              wx.showModal({
                title: '操作失败',
                content: '此手机号已被绑定！',
                showCancel: false,
              })
              page.hideedit()
            }
            
          }
        }
      })
    }
  },

  //按钮授权返回结果
  bindGetUserInfo: function (e) {
    var page = this;
    //添加用户信息
    wx.request({
      url: app.data.server + 'usersadd.php',
      data: {
        types: "add",
        openId: app.data.openId,
        nick_name: e.detail.userInfo.nickName,
        avatarUrl: e.detail.userInfo.avatarUrl,
      },
      success: function (e) {
        if (e.data != -1) {
          var userlist = e.data
          console.log(userlist)
          page.setData({
            userlist: userlist,
            shouquan: true,
          })
        }
      }
    })
  },

  //订单详情
  myOrderInfo: function (res) {
    var index = res.currentTarget.dataset.index
    var order = this.data.myOrder[index]
    wx.navigateTo({
      url: '../myOrderInfo/myOrderInfo?order=' + JSON.stringify(order),
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'myOrder.php',
      data: {
        openId: app.data.openId
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data == 0) {
          wx.showModal({
            title: '您还没有订单',
            content: '下单后可在此处查看订单记录',
            showCancel: false,
            success: function (no) {
              if (no.confirm) {
                wx.navigateBack()
              }
            }
          })
        } else {
          console.log(res.data)///////
          page.setData({
            myOrder: res.data
          })
        }
        page.threadController()
      }
    })

    //查询此用户是否已经记录在案
    wx.request({
      url: app.data.server + 'userselect.php',
      data: {
        openId: app.data.openId
      },
      success: function (re) {
        if (re.data != 0) {
          var userlist = re.data
          console.log(userlist)
          page.setData({
            userlist: userlist,
            shouquan: true,
          })
        } else {
          //未记录
          // 查看是否授权
          wx.getSetting({
            success: function (res) {
              //console.log(res.authSetting['scope.userLocation'])//用户地理位置授权
              //console.log(res.authSetting['scope.userInfo'])//用户信息授权
              if (res.authSetting['scope.userInfo']) {
                // 已经授权，可以直接调用 getUserInfo 获取头像昵称
                wx.getUserInfo({
                  success: function (res) {
                    //添加用户信息
                    wx.request({
                      url: app.data.server + 'usersadd.php',
                      data: {
                        types: "add",
                        openId: app.data.openId,
                        nick_name: res.userInfo.nickName,
                        avatarUrl: res.userInfo.avatarUrl,
                      },
                      success: function (e){
                        if(e.data!=-1){
                          var userlist = e.data
                          page.setData({
                            userlist: userlist,
                            shouquan: true,
                          })
                        }
                      }
                    })
                  }
                })
              }else{
                page.setData({
                  shouquan: false,
                })
              }
            }
          })
        }

        page.threadController()

      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})