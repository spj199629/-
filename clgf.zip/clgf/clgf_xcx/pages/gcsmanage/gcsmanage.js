// pages/gcsmanage/gcsmanage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    covershow:false,
    iconlist:[
      { class: 'icon-zhaopin', text: '应聘记录',index:'0' },
      { class: 'icon-gongchengshi', text: '工程师列表',index:'1' },
      { class: 'icon-chuqin', text: '出勤情况',index:'2' }
    ],
    yp: [
      { text: '姓名',width:'25%'},
      { text: '身份证', width: '50%' }, 
      { text: '状态', width: '25%' }
    ],
    yplist:[
      { name:'孙培峻',card:'500109199602097113',tel:'18323807482',status:'未审批'},
      { name: '孙培峻', card: '500109199602097113', tel: '18323807482', status: '未审批' },
    ],
    gcs: [
      { text: '姓名', width: '20%' },
      { text: '身份证', width: '40%' },
      { text: '在职状态', width: '20%' },
      { text: '工作状态', width: '20%' }
    ],
    gcslist:[
      { name: '孙培峻', card: '500109199602097113', tel: '18323807482', injob: '在职',work:'激活工作' },
      { name: '孙培峻', card: '500109199602097113', tel: '18323807482', injob: '在职',work:'激活工作' },
    ],
    work: [
      { text: '姓名', width: '25%' },
      { text: '身份证', width: '50%' },
      { text: '出勤次数', width: '25%' },
    ],
    worklist:[
      { name: '孙培峻', card: '500109199602097113', num:'2'},
      { name: '孙培峻', card: '500109199602097113', num:'2' },
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getdetail:function(){
    this.data.covershow = !this.data.covershow;
    this.setData({
      covershow: this.data.covershow
    })
  },
  changetable:function(e){
    var index = e.currentTarget.dataset.index;
    this.setData({
      index: index
    })
  }
})