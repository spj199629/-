// pages/clmanage/clmanage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:0,
    iconlist: [
      { class: 'icon-cheliangliebiao', text: '车辆列表', index: '0' },
      { class: 'icon-weizhi', text: '车辆位置', index: '1' },
      { class: 'icon-jihuo', text: '激活状态', index: '2' }
    ],
    cl:[
      { text:'序号' , width:'12%'},
      { text: '型号', width: '20%' },
      { text: '参数', width: '35%' },
      { text: '车牌', width: '18%' },
      { text: '驾驶员', width: '15%' },
    ],
    cllist:[
      { num: '17', version: '庆铃14m折叠臂高空作业车', parameter: '工作范围:14(米),价格:700(元),加时价:150(元)', licence:'渝D48168' ,driver:'杨政军'},
      { num: '21', version: '庆铃14m折叠臂高空作业车', parameter: '工作范围:14(米),价格:700(元),加时价:150(元)', licence: '渝D53673', driver: '王传浩' },
      { num: '22', version: '庆铃14m折叠臂高空作业车', parameter: '工作范围:14(米),价格:700(元),加时价:150(元)', licence: '渝70290', driver: '张号东' },
      { num: '22', version: '庆铃14m折叠臂高空作业车', parameter: '工作范围:14(米),价格:700(元),加时价:150(元)', licence: '渝70290', driver: '张号东' },
      { num: '22', version: '庆铃14m折叠臂高空作业车', parameter: '工作范围:14(米),价格:700(元),加时价:150(元)', licence: '渝70290', driver: '张号东' },
    ],
    active:[
      { text: '车牌号', width: '18%' },
      { text: '驾驶员', width: '15%' },
      { text: '状态', width: '12%' },
      { text: '操作', width: '55%' },
    ],
    activelist: [
      { licence: '渝D48168', driver: '杨政军',active:'未激活' },
      { licence: '渝D53673', driver: '王传浩', active: '未激活' },
      { licence: '渝70290', driver: '张号东', active: '未激活' },
    ],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  getdetail: function () {
    this.data.covershow = !this.data.covershow;
    this.setData({
      covershow: this.data.covershow
    })
  },
  changetable: function (e) {
    var index = e.currentTarget.dataset.index;
    this.setData({
      index: index
    })
  }
})