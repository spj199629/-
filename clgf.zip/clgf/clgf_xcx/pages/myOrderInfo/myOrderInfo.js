// pages/myOrderInfo/myOrderInfo.js
const app = getApp()
const timeUtil = require('../../utils/timeUtil.js')
const threadAmount = 1
var threadFinish = 0

Page({

  /**
   * 页面的初始数据
   */
  data: {
    //地图是否显示
    mapstart: false,
    //位置
    mapLocation: [{
      latitude: 29.582170,
      longitude: 106.560580,
      iconPath: '../../resource/location.png',
      title: "",
      width: 30,
      height: 30
    }],
    //施工日期
    dateList: "请选择",
    timeList: "请选择",
    timeArray: [['06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'], ['00', '10', '20', '30', '40', '50']],
    pause: false,
    rentForm: {}
  },

  //联系工程师
  call: function () {
    wx.makePhoneCall({
      phoneNumber: this.data.rentForm.engineerPhone,
    })
  },

  //在线支付
  toOnlinePay: function () {
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    var page = this
    wx.request({
      url: app.data.server + 'toOnlinePay.php',
      data: {
        orderId: page.data.rentForm.orderId,
        payFee: page.data.rentForm.onlineSumCost,
        openId: app.data.openId,
        order_no: page.data.rentForm.order_no
      },
      success: function (prePayBack) {
        //console.log(prePayBack.data)
        wx.requestPayment({
          appId: prePayBack.data.appId,
          nonceStr: prePayBack.data.nonceStr,
          package: prePayBack.data.package,
          signType: prePayBack.data.signType,
          timeStamp: prePayBack.data.timeStamp,
          paySign: prePayBack.data.paySign,
          success: function (success) {
            wx.hideLoading()
            wx.showModal({
              title: '支付成功',
              showCancel: false,
              success: res => {
                if (res.confirm) {
                  page.setData({
                    'rentForm.payState': 1,
                    'rentForm.payMethod': 1
                  })
                }
              }
            })
          },
          fail: function (fail) {
            wx.hideLoading()
            wx.showModal({
              title: '支付失败',
              content: '您取消了支付或者网络请求错误，未完成支付（未扣款）',
              showCancel: false,
            })
          }
        })
      }
    })
  },

  //取消订单
  cancel: function () {
    const page = this
    wx.showModal({
      title: '确定取消订单吗？',
      content: '在线支付用户请联系客服进行退款',
      cancelText: '否',
      confirmText: '是',
      success: function (modal) {
        if (modal.confirm) {
          wx.showLoading({
            title: '正在提交',
            mask: true
          })
          wx.request({
            url: app.data.server + 'cancelOrder.php',
            data: {
              orderId: page.data.rentForm.orderId,
              engineerName: page.data.rentForm.engineerName,
              engineerPhone: page.data.rentForm.engineerPhone
            },
            success: function (res) {
              wx.hideLoading()
              if (res.data == 1) {
                wx.showModal({
                  title: '已取消',
                  content: '此订单已成功取消',
                  showCancel: false,
                  success: function (cM) {
                    if (cM.confirm) {
                      wx.navigateBack({})
                    }
                  }
                })
              } else {
                wx.showModal({
                  title: '取消失败',
                  content: '网络连接失败，请稍后再试',
                  showCancel: false
                })
              }
            }
          })
        }
      }
    })
  },

  //评价订单
  evaluate: function () {
    wx.navigateTo({
      url: '../evaluate/evaluate?orderId=' + this.data.rentForm.orderId,
    })
  },

  //订单加时
  overtime: function () {
    wx.navigateTo({
      url: '../overtime/overtime?orderId=' + this.data.rentForm.orderId,
    })
  },

  //改签
  gaiqiansave: function() {
    var page = this
    var workTime = page.data.dateList + ' ' + page.data.timeList + ':00'//施工时间
    if (page.data.timeList=="请选择"){
      wx.showModal({
        title: '改签失败',
        content: '开工时间不能为空',
      })
      return;
    }

    var sysDateTime = new Date()
    sysDateTime.setHours(sysDateTime.getHours() + 4)
    var orderDateTime = new Date(page.data.rentForm.workTime.replace(/-/g, '/'))
    if (orderDateTime < sysDateTime && page.data.rentForm.startTime!=null) {
      wx.showModal({
        title: '改签失败',
        content: '当前时间不允许改签',
      })
      return;
    }

    var aatime = new Date(workTime.replace(/-/g, '/'))
    if (aatime < sysDateTime){
      wx.showModal({
        title: '改签失败',
        content: '选择时间最少要在当前时间延后4小时',
      })
      return;
    }

    
    wx.request({
      url: app.data.server + 'gaiqiansave.php',
      data: {
        orderId: page.data.rentForm.orderId,
        workTime: workTime
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data == 1) {
          wx.showModal({
            title: '改签成功',
            content: '',
            showCancel: false,
            success: function (cM) {
              if (cM.confirm) {
                wx.navigateBack({})
              }
            }
          })
        } else {
          wx.showModal({
            title: '改签失败',
            content: '网络连接失败，请稍后再试',
            showCancel: false
          })
        }
      }
    })
  },

  timeFormat(param) {//小于10的格式化函数
    return param < 10 ? '0' + param : param;
  },
  countDown: function () {//倒计时函数
    const page = this
    // 获取当前时间，同时得到活动结束时间数组
    var newTime = new Date().getTime();
    var endTimeList = page.data.rentForm.estimate_endtime;
    var countDownArr = [];

    // 对结束时间进行处理渲染到页面
    var endTime = new Date(endTimeList).getTime();
    //let obj = null;
    // 如果活动未结束，对时间进行处理
    /*wx.showModal({
      title: '时间',
      content: '结束时间：' + endTime + "当前时间：" + newTime,
    })*/
    if (endTime - newTime > 0) {
      var time = (endTime - newTime) / 1000;
      // 获取天、时、分、秒
      var day = parseInt(time / (60 * 60 * 24));
      var hou = parseInt(time % (60 * 60 * 24) / 3600);
      var min = parseInt(time % (60 * 60 * 24) % 3600 / 60);
      var sec = parseInt(time % (60 * 60 * 24) % 3600 % 60);
      day = page.timeFormat(day)
      hou = page.timeFormat(hou)
      min = page.timeFormat(min)
      sec = page.timeFormat(sec)
      page.setData({
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    } else {//活动已结束，全部设置为'00'
      day = '00'
      hou = '00'
      min = '00'
      sec = '00'
      page.setData({
        pause: false,
        timingText: hou + '小时' + min + '分' + sec + '秒'
      })
    }

    //countDownArr.push(obj);
    // 渲染，然后每隔一秒执行一次倒计时函数
    //page.setData({ countDownList: countDownArr })
    if (page.data.pause) {
      //setTimeout(page.countDown(), 1000);
      setTimeout(function () {
        page.countDown()
      }, 1000)
    }
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      wx.hideLoading()
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var order = JSON.parse(options.order)
    var page = this
    threadFinish = 0
    var dateList = order.workTime.slice(0, 10)
    dateList = dateList.split("-");//字符串转数组
    var a = []
    for(var i=0;i<3;i++){
      a[i] = (Number)(dateList[i])
      //a[i] = dateList[i].replace(/\b(0+)/gi, "")
    }
    dateList = a.join("-");//数组转字符串
    //console.log(dateList)
    page.setData({
      rentForm: order,
      dateList: dateList
    })
    if (order.startTime != null && order.endTime == null) {
      page.setData({
        pause: true
      })
      page.countDown();
    }

    //判断是否该显示地图
    var ditustate = true;
    var sysDateTime = new Date()
    sysDateTime.setHours(sysDateTime.getHours() + 1)
    var orderDateTime = new Date(page.data.rentForm.workTime.replace(/-/g, '/'))
    //orderDateTime = sysDateTime + 1//////////////////////////////不验证
    if (orderDateTime < sysDateTime && page.data.rentForm.workState==0) {
      ditustate = false;
    }
    page.setData({
      ditustate: ditustate
    })
    //地图获取经纬度
    var carLicense = order.carLicense
    //查询车辆位置
    //获取车辆类型
    wx.request({
      url: app.data.server + 'caraddress.php',
      data: {
        carLicense: carLicense
      },
      success: function (carRes) {
        if (carRes.data != -1 && carRes.data != 0) {
          const caraddress = carRes.data
          var mapLocation = [{
            latitude: caraddress.tx_latitude,
            longitude: caraddress.tx_longitude,
            iconPath: '../../resource/location.png',
            title: carLicense,
            width: 30,
            height: 30
          }]
          //console.log(mapLocation)
          page.setData({
            mapLocation: mapLocation,
            latitude: caraddress.tx_latitude,
            longitude: caraddress.tx_longitude
          })
          page.threadController()
        }
      }
    })

    //判断是否能够改签
    var gaiqianTime = true;
    if (page.data.rentForm.startTime != null || page.data.rentForm.workState ==2){
      gaiqianTime = false;
    }
    /*var sysDateTime = new Date()
    sysDateTime.setHours(sysDateTime.getHours() + 4)
    var orderDateTime = new Date(page.data.rentForm.workTime.replace(/-/g, '/'))
    if (orderDateTime < sysDateTime) {
      gaiqianTime = false;
    }*/
    //console.log(page.data.rentForm.endTime)
    page.setData({
      gaiqianTime: gaiqianTime
    })

    /**日历**/
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    let riqi = year + "-" + month + "-" + now.getDate();
    let timestamp = parseInt((new Date(riqi)) / 1000);
    page.dateInit();
    page.setData({
      year: year,
      month: month,
      isToday: '' + year + month + now.getDate(),
      timestamp: timestamp
    })
    /***end***/
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //选择时间
  pickerTime: function (e) {
    var value = this.data.timeArray[0][e.detail.value[0]] + ':' + this.data.timeArray[1][e.detail.value[1]]
    var timeList = this.data.timeList
    timeList = value
    this.setData({
      timeList: timeList
    })
  },

  //打开日历
  showRule: function () {
    this.dateInit()
    this.setData({
      isRuleTrue: true
    })
  },

  //选择日期
  daychoice: function (e) {
    const page = this
    var riqi = (e.currentTarget.id)
    page.setData({
      dateList: riqi,
      isRuleTrue: false//关闭日历
    })
  },

  //关闭日历
  hideRule: function () {
    this.setData({
      isRuleTrue: false
    })
  },



  dateInit: function (setYear, setMonth) {
    var page = this;
    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = [];						//需要遍历的日历数组数据
    let arrLen = 0;							//dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();					//没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 1 : (month + 1);
    let startWeek = new Date(year + '/' + (month + 1) + '/' + 1).getDay();//目标月1号对应的星期，ios只支持“/”写法日期
    let dayNums = new Date(year, nextMonth, 0).getDate();				//获取目标月有多少天
    let obj = {};
    let num = 0;
    let classs = "";

    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    arrLen = startWeek + dayNums;

    
    //获取车辆是否有空
    wx.request({
      url: app.data.server + 'gaiqian.php',
      data: {
        Year: year,//年
        Month: month + 1,//月
        dayNums: dayNums,//天数
        carLicense: this.data.rentForm.carLicense//车牌号
      },
      success: function (carRes) {
        if (carRes.data != -1) {
          let daystate = carRes.data
          for (let i = 0; i < arrLen; i++) {
            if (i >= startWeek) {
              num = i - startWeek + 1;
              let daysta = daystate[i - startWeek].state
              if (daysta == 1) {
                classs = "day-bg-yes";
              } else {
                classs = "day-bg-no";
              }
              let riqi = (year + "-" + (month + 1) + "-" + num).replace(/-/g, '/')
              //console.log(riqi)
              obj = {
                isToday: '' + year + (month + 1) + num,
                dateNum: num,
                weight: 5,
                classs: classs,
                riqi: riqi,
                timestamp: parseInt((new Date(riqi)) / 1000)
              }
            } else {
              obj = {};
            }
            dateArr[i] = obj;
          }
          //console.log(dateArr)
          page.setData({
            dateArr: dateArr
          })
        }
      }
    })



    let nowDate = new Date();
    let nowYear = nowDate.getFullYear();
    let nowMonth = nowDate.getMonth() + 1;
    let nowWeek = nowDate.getDay();
    let getYear = setYear || nowYear;
    let getMonth = setMonth >= 0 ? (setMonth + 1) : nowMonth;

    if (nowYear == getYear && nowMonth == getMonth) {
      this.setData({
        isTodayWeek: true,
        todayIndex: nowWeek
      })
    } else {
      this.setData({
        isTodayWeek: false,
        todayIndex: -1
      })
    }
  },
  lastMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  },
  nextMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  }
})