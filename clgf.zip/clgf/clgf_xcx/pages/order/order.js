// pages/order/order.js
const app = getApp()
const timeUtil = require('../../utils/timeUtil.js')
const pickDateUtil = require('../../utils/pickDateUtil.js')
const threadAmount = 1
var threadFinish = 0

Page({

  /**
   * 页面的初始数据
   */
  data: {     
    //地图控件显示
    mapstart: false,
    //施工日期
    riqi: "施工日期",
    /***日历****/
    year: 0,
    month: 0,
    date: ['日', '一', '二', '三', '四', '五', '六'],
    dateArr: [],
    isToday: 0,
    isTodayWeek: false,
    todayIndex: 0,
    /****end****/
    //预计时长
    timenum: 0,
    //租用车辆信息
    cartypeList:[],
    //日期与时间
    startDate: '',
    endDate: '',
    timeArray: [['06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'], ['00', '30']],
    //位置
    mapLocation: [{
      latitude: 29.582170,
      longitude: 106.560580,
      addressName: '请选择施工地点',
      address: '点击地图选择位置',
      iconPath: '../../resource/location.png',
      width: 30,
      height: 30
    }],
    isDefaultLocation: true,

    //施工日期、时间
    dateList: "请选择",
    timeList: "请选择"
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      wx.hideLoading()
    }
  },

  //预计时间选择
  pickPredictTime: function (e) {
    const page = this
    const timenum = (Number)(e.detail.value)
    page.setData({
      timenum: timenum
    })
  },

  //选择日期
  pickerDate: function (e) {
    var value = e.detail.value
    var dateList = this.data.dateList
    dateList = value
    this.setData({
      dateList: dateList
    })
  },

  //选择时间
  pickerTime: function (e) {
    var value = this.data.timeArray[0][e.detail.value[0]] + ':' + this.data.timeArray[1][e.detail.value[1]]
    var timeList = this.data.timeList
    timeList = value
    this.setData({
      timeList: timeList
    })
  },

  

  //选择施工地点
  workAddress: function () {
    var page = this
    wx.chooseLocation({
      success: res => {
        if (res.name != null || res.address != null) {
          var workLocation = page.data.mapLocation
          workLocation[0].latitude = res.latitude
          workLocation[0].longitude = res.longitude
          workLocation[0].addressName = res.name
          workLocation[0].address = res.address
          if (page.data.isDefaultLocation) {
            page.setData({
              mapLocation: workLocation,
              isDefaultLocation: false
            })
          } else {
            page.setData({
              mapLocation: workLocation
            })
          }
        }
      },
      fail: resFail => {
        wx.getSetting({
          success(resSetting) {
            if (!resSetting.authSetting['scope.userLocation']) {
              wx.hideLoading()
              wx.showModal({
                title: '您拒绝了位置授权',
                content: '我们需要您在地图上标记使用租车的地点，这需要使用您的粗略位置展开地图。点击确定后将跳转到设置，请打开地理位置授权。点击取消退出。',
                success: function (resModal) {
                  if (resModal.confirm) {
                    wx.openSetting({})
                  } else if (resModal.cancel) {
                    wx.navigateBack({})
                  }
                }
              })
            }
          }
        })
      }
    })
  },

  
  //表单提交
  rentFormSubmit: function (e) {
    wx.showLoading({
      title: '正在保存',
      mask: true
    })
    const page = this
    //非空验证
    var nullItem = []
    if (page.data.isDefaultLocation) {
      nullItem.push('施工地点')
    }
    if (e.detail.value.renterName == '') {
      nullItem.push('租用人姓名')
    }
    if (e.detail.value.renterPhone.length < 11) {
      nullItem.push('租用人手机')
    }
    if (page.data.dateList =='请选择') {
      nullItem.push('施工日期')
    }
    if (page.data.timeList == '请选择') {
      nullItem.push('施工时间')
    }
    //nullItem.length = 0////////////////////////////////不验证
    //表单整理
    if (nullItem.length == 0) {
      var trueTime = true;
      var rentForm = {}
      rentForm.workTime = page.data.dateList + ' ' + page.data.timeList + ':00'//施工时间
      //用车时间延后2小时
      var sysDateTime = new Date()
      sysDateTime.setHours(sysDateTime.getHours() + 2)
      var orderDateTime = new Date(rentForm.workTime.replace(/-/g, '/'))
      //orderDateTime = sysDateTime + 1//////////////////////////////不验证
      if (orderDateTime < sysDateTime) {
        trueTime = false;
      }
      if (trueTime) {
        var location = page.data.mapLocation[0]
        rentForm.workLatitude = location.latitude
        rentForm.workLongitude = location.longitude
        rentForm.workaddressName = location.addressName
        rentForm.workaddresslist = location.address
        rentForm.workAddress = location.addressName + '(' + location.address + ')'

        rentForm.renterName = e.detail.value.renterName//租用人
        rentForm.renterPhone = e.detail.value.renterPhone//租用人手机
        rentForm.servicetime = page.data.timenum//租用时间
        rentForm.cartypeList = page.data.cartypeList//租用车辆信息
        rentForm.formId = e.detail.formId
        wx.hideLoading()
        //console.log(rentForm)
        wx.navigateTo({
          url: '../payInfo/payInfo?rentForm=' + JSON.stringify(rentForm),
          //url: '../payInfo/payInfo?rentForm=' + JSON.stringify(rentForm) + '&otherText=' + JSON.stringify(otherText),
          //url: '../ordertwo/ordertwo?rentForm=' + JSON.stringify(rentForm),
        })
      } else {
        wx.hideLoading()
        wx.showModal({
          title: '用车时间过早',
          content: '请至少预留2小时以便车辆赶往现场，如有紧急情况请下单后联系客服',
          showCancel: false
        })
      }
    } else {
      var note = '请检查：'
      for (var i = 0; i < (nullItem.length - 1); i++) {
        note += (nullItem[i] + '、')
      }
      note += nullItem[i]
      wx.hideLoading()
      wx.showModal({
        title: '订单有空缺项',
        content: note,
        showCancel: false
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showLoading({
      title: ' 正在加载',
      mask: true
    })
    threadFinish = 0
    const page = this
    //获取工作时长
    wx.request({
      url: app.data.server + 'servicetime.php',
      success: function (res) {
        if (res.data != -1 && res.data != 0) {
          const serviceArray = res.data
          var array = []
          for (var i = 0; i < serviceArray.length; i++) {
            if (i == 0) {
              var mintime = serviceArray[i].astime
            }
            if (i == (serviceArray.length - 1)) {
              var maxtime = serviceArray[i].astime
            }
          }

          page.setData({
            timenum: mintime,
            mintime: mintime,
            maxtime: maxtime,
          })
          page.threadController()
        }

      },
      fail: resFail => {
        wx.showModal({
          title: "失败",
          content: "请求失败",
          showCancel: false
        })
      }
    })
    //获取施工类型
    /*wx.request({
      url: app.data.server + 'workType.php',
      success: function (workRes) {
        if (workRes.data != -1 && workRes.data != 0) {
          const workTypeArray = workRes.data
          var array1 = []
          for (var i = 0; i < workTypeArray.length; i++) {
            if (workTypeArray[i].parentId == 0) {
              array1.push(workTypeArray[i].name)
            }
          }
          var array2 = []
          for (var i = 0; i < workTypeArray.length; i++) {
            if (workTypeArray[i].parentId == workTypeArray[0].id) {
              array2.push(workTypeArray[i].name)
            }
          }
          var pickWorkType = [array1, array2]
          page.setData({
            workTypeArray: workTypeArray,
            pickWorkType: pickWorkType
          })
          page.threadController()
        }
      }
    })
    //获取车辆类型
    wx.request({
      url: app.data.server + 'carType.php',
      success: function (carRes) {
        if (carRes.data != -1 && carRes.data != 0) {
          const carArray = carRes.data
          var array = []
          for (var i = 0; i < carArray.length; i++) {
            array.push(carArray[i].length + '米' + carArray[i].quality + 'kg')
          }
          page.setData({
            carTypeArray: carArray,
            pickCarType: array
          })
          page.threadController()
        }
      }
    })*/
    //系统时间
    var nowDate = new Date()
    const startDate = pickDateUtil.formatTime(nowDate)
    const endDate = pickDateUtil.formatTime(new Date(nowDate.setDate(nowDate.getDate() + 30)))
    //已选择车辆
    var cartypeList = JSON.parse(options.cartypeList)
    page.setData({
      cartypeList: cartypeList,
      startDate: startDate,
      endDate: endDate
    })

    /**日历**/
    let now = new Date();
    let year = now.getFullYear();
    let month = now.getMonth() + 1;
    let riqi = (year + "/" + month + "/" + now.getDate());
    let timestamp = parseInt((new Date(riqi)) / 1000);
    page.dateInit();
    page.setData({
      year: year,
      month: month,
      isToday: '' + year + month + now.getDate(),
      timestamp: timestamp
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },



  //打开日历
  showRule: function () {
    this.dateInit()
    this.setData({
      mapstart: true,
      isRuleTrue: true
    })
  },

  //选择日期
  daychoice: function (e) {
    const page = this
    var riqi = (e.currentTarget.id)
    page.setData({
      dateList: riqi,
      mapstart: false,
      isRuleTrue: false//关闭日历
    })
  },

  //关闭日历
  hideRule: function () {
    this.setData({
      mapstart: false,
      isRuleTrue: false
    })
  },


  
  dateInit: function (setYear, setMonth) {
    var page = this;
    //全部时间的月份都是按0~11基准，显示月份才+1
    let dateArr = [];						//需要遍历的日历数组数据
    let arrLen = 0;							//dateArr的数组长度
    let now = setYear ? new Date(setYear, setMonth) : new Date();
    let year = setYear || now.getFullYear();
    let nextYear = 0;
    let month = setMonth || now.getMonth();					//没有+1方便后面计算当月总天数
    let nextMonth = (month + 1) > 11 ? 1 : (month + 1);
    let startWeek = new Date(year + '/' + (month + 1) + '/' + 1).getDay();							//目标月1号对应的星期
    let dayNums = new Date(year, nextMonth, 0).getDate();				//获取目标月有多少天
    let obj = {};
    let num = 0;
    let classs = "";

    if (month + 1 > 11) {
      nextYear = year + 1;
      dayNums = new Date(nextYear, nextMonth, 0).getDate();
    }
    arrLen = startWeek + dayNums;


    var cartypeList = this.data.cartypeList
    var typeId = "";
    for(var i=0;i<cartypeList.length;i++){
      if (typeId==""){
        typeId = cartypeList[i]["typeId"];
      }else{
        typeId = typeId+":"+cartypeList[i]["typeId"];
      }
    }


    //车辆类型
    //获取车辆是否有空
    wx.request({
      url: app.data.server + 'carfree.php',
      data: {
        Year: year,//年
        Month: month+1,//月
        dayNums: dayNums,//天数
        typeId: typeId,//类型
        bus_id: app.data.business.bus_id,//商家id
      },
      success: function (carRes) {
        if (carRes.data != -1) {
          let daystate = carRes.data
          for (let i = 0; i < arrLen; i++) {
            if (i >= startWeek) {
              num = i - startWeek + 1;
              let daysta = daystate[i - startWeek].state
              if (daysta == 1) {
                classs = "day-bg-yes";
              } else {
                classs = "day-bg-no";
              }
              let riqi = (year + "-" + (month + 1) + "-" + num).replace(/-/g, '/')
              obj = {
                isToday: '' + year + (month + 1) + num,
                dateNum: num,
                weight: "",
                classs: classs,
                riqi: riqi,
                timestamp: parseInt((new Date(riqi)) / 1000)
              }
            } else {
              obj = {};
            }
            dateArr[i] = obj;
          }
          //console.log(dateArr)
          page.setData({
            dateArr: dateArr
          })
        }
      }
    })



    let nowDate = new Date();
    let nowYear = nowDate.getFullYear();
    let nowMonth = nowDate.getMonth() + 1;
    let nowWeek = nowDate.getDay();
    let getYear = setYear || nowYear;
    let getMonth = setMonth >= 0 ? (setMonth + 1) : nowMonth;

    if (nowYear == getYear && nowMonth == getMonth) {
      this.setData({
        isTodayWeek: true,
        todayIndex: nowWeek
      })
    } else {
      this.setData({
        isTodayWeek: false,
        todayIndex: -1
      })
    }
  },
  lastMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month - 2 < 0 ? this.data.year - 1 : this.data.year;
    let month = this.data.month - 2 < 0 ? 11 : this.data.month - 2;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  },
  nextMonth: function () {
    //全部时间的月份都是按0~11基准，显示月份才+1
    let year = this.data.month > 11 ? this.data.year + 1 : this.data.year;
    let month = this.data.month > 11 ? 0 : this.data.month;
    this.setData({
      year: year,
      month: (month + 1)
    })
    this.dateInit(year, month);
  }


})