// pages/coupon/coupon.js
//优惠券
var app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    couponstate: true,
    phone: "",
    coupon_id: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var page = this
    wx.request({
      url: app.data.server + 'couponlist.php',
      data: {
        openId: app.data.openId
      },
      success: function (res) {
        wx.hideLoading()
        if (res.data != 0) {
          console.log(res.data)///////
          page.setData({
            couponlist: res.data
          })
        }else{
          page.setData({
            couponstate: false,
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //打开更新信息面板
  showedit: function (e) {
    console.log(e)
    var index = e.currentTarget.dataset.index
    var coupon_id = this.data.couponlist[index].id
    this.setData({
      coupon_id: coupon_id,
      mapstart: true,
      isRuleTrue: true
    })
  },

  //关闭更新信息面板
  hideedit: function () {
    this.setData({
      phone: "",
      coupon_id: "",
      mapstart: false,
      isRuleTrue: false
    })
  },

  //表单提交
  registerForm: function (e) {
    var page = this;
    if (e.detail.value.phone == '' || e.detail.value.phone.length != 11) {
      wx.hideLoading()
      wx.showModal({
        title: '信息不完整',
        content: '请检查',
        showCancel: false
      })
    } else {
      //提交登记
      wx.request({
        url: app.data.server + 'couponedit.php',
        data: {
          openId: app.data.openId,
          phone: e.detail.value.phone,
          coupon_id: page.data.coupon_id,
        },
        success: function (res) {
          if (res.data != 0) {
            var couponlist = res.data.e
            var state = res.data.state
            console.log(res.data)///////
            if(state==-2){
              wx.showModal({
                title: '赠送失败',
                content: '没有找到此手机号！',
                showCancel: false,
              })
            }
            if (state == 1) {
              wx.showModal({
                title: '赠送成功',
                content: '',
                showCancel: false,
              })
            }
            page.setData({
              couponlist: couponlist
            })
          } else {
            page.setData({
              couponstate: false,
            })
          }
          page.hideedit()
        }
      })
    }
  },
})