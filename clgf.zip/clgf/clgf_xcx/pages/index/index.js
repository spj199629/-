// pages/index/index.js
const app = getApp()
const threadAmount = 2
var threadFinish = 0

Page({
  
  /**
   * 页面的初始数据
   */
  data: {
    beijing: '',
    logoUrl: '',
    userIdentify: 0,
    swiperImagesUrl: [],
    business:[],
    busArray:[],
    cstate: 1,
    imgUrls: [
      '../img/ln.png',
      '../img/gkfw1.jpg',
      '../img/gkxs.jpg'
    ],
    initslider: [
      { class: 'icon-yuding', text: '预定施工' ,bind:"order",userid:['0','1','2']},
      { class: 'icon-hezuo', text: '加入我们', bind: "join", userid: ['0']},
      { class: 'icon-kefu', text: '联系客服', bind: "call", userid: ['0']}
    ],
    slider: [
      
    ],
    region:[],
    customItem: '全部',
    productUrls: [
      'http://gf.tover.group/static/web/image/%E4%B8%9C%E9%A3%8E17.6m%E7%BB%9D%E7%BC%98%E8%87%82%E9%AB%98%E7%A9%BA%E4%BD%9C%E4%B8%9A%E8%BD%A6.png ',
      'http://gf.tover.group/static/web/image/%E6%B1%9F%E9%93%8314m%E6%8A%98%E5%8F%A0%E8%87%82%E9%AB%98%E7%A9%BA%E4%BD%9C%E4%B8%9A%E8%BD%A6.png',
      'http://gf.tover.group/static/web/image/%E5%BA%86%E9%93%8315.2m%E6%8A%98%E5%8F%A0%E8%87%82%E9%AB%98%E7%A9%BA%E4%BD%9C%E4%B8%9A%E8%BD%A6.png',
      'http://gf.tover.group/static/web/image/%E4%B8%9C%E9%A3%8E32m%E6%B7%B7%E5%90%88%E8%87%82%E9%AB%98%E7%A9%BA%E4%BD%9C%E4%B8%9A%E8%BD%A6.png',
      'http://gf.tover.group/static/web/image/%E5%BA%86%E9%93%83%E4%B8%9C%E9%A3%8E25.4m%E7%BB%9D%E7%BC%98%E8%87%82%E9%AB%98%E7%A9%BA%E4%BD%9C%E4%B8%9A%E8%BD%A6.png'
    ],
  },

  //多线程控制器
  threadController: function () {
    threadFinish++;
    if (threadFinish == threadAmount) {
      //console.log(app.data.openId)
      wx.request({
        url: app.data.server + 'orderjiance.php',
        data: {
          openId: app.data.openId
        },
        success: function (e) {
          if (e.data != 0) {
            const orderarray = e.data
            var order = orderarray[0]
            wx.showModal({
              title: '订单到时提醒',
              content: '您的订单即将到时，是否续费',
              showCancel: true,//是否显示取消按钮
              cancelText: '否',//默认是“取消”
              confirmText: '是',
              success: function (res) {
                if (res.cancel) {
                  //点击取消,默认隐藏弹框
                } else {
                  //点击确定
                  wx.navigateTo({
                    //url: '../myOrderInfo/myOrderInfo?order=' + JSON.stringify(order),
                    url: '../xufei/xufei?order=' + JSON.stringify(order),
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          }
        }
      }),

      wx.request({
        url: app.data.server + 'engineerorder.php',
        data: {
          openId: app.data.openId
        },
        success: function (e) {
          if (e.data != 0) {
            const orderId = e.data.orderId
            wx.showModal({
              title: '新订单提醒',
              content: '您有新的订单，是否接受',
              showCancel: true,//是否显示取消按钮
              cancelText: '否',//默认是“取消”
              confirmText: '是',
              success: function (res) {
                if (res.cancel) {
                  //点击取消,默认隐藏弹框
                  wx.request({
                    url: app.data.server + 'engineerorderstate.php',
                    data: {
                      orderId: orderId,
                      state: 0
                    },
                    success: function (se) {
                      if (se.data == -2) {
                        wx.showModal({
                          title: '操作失败',
                          content: '暂无其他空闲车辆，请联系管理员手动操作',
                          showCancel: false,
                        })
                      }
                    }
                  })
                } else {
                  //点击确定
                  wx.request({
                    url: app.data.server + 'engineerorderstate.php',
                    data: {
                      orderId: orderId,
                      state: 1
                    },
                  })
                }
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          }
        }
      })

      //获取当前经纬度信息
      wx.getLocation({
        success: ({ latitude, longitude }) => {
          //调用后台API，获取地址信息
          console.log("经度" +latitude)
          console.log("纬度"+longitude)
          wx.request({
            url: 'https://apis.map.qq.com/ws/geocoder/v1/',
            data:{
              location: latitude + "," + longitude,
              key: 'LJHBZ-GIQK3-ZCD3O-3ICZF-5KUJ2-R3FKU'
            },

            success: (res) => {
              var addre = res.data.result.ad_info
              var init = []
              init[0] = addre.province,
              init[1] = addre.city,
              init[2] = addre.district,
              app.data.province = addre.province,
              app.data.city = addre.city,
              app.data.district = addre.district,
              //初始化地址
              this.setData({
                region:init
              })
              //获取公司信息
              this.buslist();
            },

            fail: () => {
            },

            complete: () => {
            }
          })
        }
      })
      wx.hideLoading()
    }
  },
  RegionChange:function(e){
    this.setData({
      region: e.detail.value
    })
    app.data.province = this.data.region[0],
    app.data.city = this.data.region[1],
    app.data.district = this.data.region[2]
    this.buslist();
  },
  //选择一个公司
  buslink: function(){

  },

  //根据地址获取公司信息
  buslist: function(){
    var page = this;
    //查询公司
    wx.request({
      url: app.data.server + 'business.php',
      data: {
        province: app.data.province,
        city: app.data.city,
        district: app.data.district,
      },
      success: function (e) {
        //如果有多个公司，弹窗选择默认公司，如果只有一个，则默认该公司
        var business = e.data
        if (business.length > 1) {
          //公司有多个
          page.setData({
            busArray: business,
            business: [],
          })
          app.data.business = []
        } else {
          //公司只有一个
          page.setData({
            busArray: [],
            business: business[0],
          })
          app.data.business = business[0]
        }
      }
    })
  },
  previewImage: function (e) {
    wx.previewImage({
      current: e.currentTarget.dataset.src,
      urls: [
        e.currentTarget.dataset.src
      ]
    })
  },
  //预定施工
  ordertwo: function () {
    wx.navigateTo({
      url: '../order/order',
    })
  },

  //车辆管理
  car: function () {
    wx.navigateTo({
      url: '../car/car',
    })
  },

  //抽奖
  choujiang: function () {
    wx.navigateTo({
      url: '../choujiang5/choujiang5',
    })
  },

  order: function () {
    wx.navigateTo({
      url: '../ordertwo/ordertwo',
    })
  },

  //我的订单
  myOrder: function () {
    wx.navigateTo({
      url: '../myOrder/myOrder',
    })
  },

  //注册工程师
  updateInfo: function (e) {
    wx.navigateTo({
      url: '../engineerRegister/engineerRegister',
    })
  },

  //联系客服
  call: function () {
    wx.showLoading({
      title: '正在获取客服联系方式',
      mask: true
    })
    wx.request({
      url: app.data.server + 'getCallPhone.php',
      success: function (e) {
        wx.hideLoading()
        wx.makePhoneCall({
          phoneNumber: e.data.toString(),
        })
      }
    })
  },

  //加入我们
  join: function () {
    wx.navigateTo({
      url: '../join/join',
    })
  },

  //工程师
  engineer: function () {
    wx.navigateTo({
      url: '../engineer/engineer',
    })
  },

  //管理员
  manager: function () {
    wx.navigateTo({
      url: '../manager/manager',
    })
  },

  //公司简介
  about: function () {
    wx.navigateTo({
      url: '../about/about',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    cstate: options.cstate;
    wx.showLoading({
      title: '正在加载',
      mask: true
    })
    threadFinish = 0
    const page = this
    wx.login({
      success: function (loginRes) {
        if (loginRes.code) {
          //获取openid
          wx.request({
            url: app.data.server + 'openId.php',
            data: {
              code: loginRes.code
            },
            success: function (openIdRes) {
              if (openIdRes.data == 0) {
                wx.hideLoading()
                wx.showLoading({
                  title: '微信openId连接失败，请稍后再试',
                  mask: true
                })
              } else {
                app.data.openId = openIdRes.data.openid
                //判断用户身份
                wx.request({
                  url: app.data.server + 'userIdentify.php',
                  data: {
                    openId: app.data.openId
                  },
                  success: function (identifRes) {
                    if (identifRes.data == -1) {
                      wx.hideLoading()
                      wx.showLoading({
                        title: '数据库连接失败，请稍后再试',
                        mask: true
                      })
                    } else {
                      var array = []
                      for(var i=0;i<page.data.initslider.length;i++){
                        var userid = page.data.initslider[i].userid
                          for(var j in userid){
                            if(userid[j] == identifRes.data){
                              array.push(page.data.initslider[i])
                            }
                          }
                      }
                      page.setData({
                        slider: array
                      })
                      page.setData({
                        userIdentify: identifRes.data
                      })
                      page.threadController();
                    }
                  }
                })
              }
            }
          })
          //获取系统版本
          wx.request({
            url: app.data.server + 'version.php',
            success: function (versionRes) {
              if (versionRes.data == -1) {
                wx.hideLoading()
                wx.showLoading({
                  title: '数据库连接失败，请稍后再试',
                  mask: true
                })
              } else {
                app.data.version = versionRes.data
                const swiperImagesUrl = [
                  //app.data.server + 'appResource/index1_v' + app.data.version + '.png',
                  //app.data.server + 'appResource/index2_v' + app.data.version + '.png',
                  //app.data.server + 'appResource/index3_v' + app.data.version + '.png',
                  //app.data.server + 'appResource/index4_v' + app.data.version + '.png',
                  app.data.server + 'appResource/index5_v' + app.data.version + '.png'
                ]
                page.setData({
                  beijing: app.data.server + 'appResource/index_bg.jpg',
                  //swiperImagesUrl: swiperImagesUrl,
                  logoUrl: app.data.server + 'appResource/logo.png',
                })
                page.threadController();
              }
            }
          })
        } else {
          wx.hideLoading()
          wx.showLoading({
            title: '微信登陆失败，请稍后再试' + loginRes.errMsg,
            mask: true
          })
        }
      }
    })
  },
  bindRegionChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
})